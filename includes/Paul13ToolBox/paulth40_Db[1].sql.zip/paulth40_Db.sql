-- phpMyAdmin SQL Dump
-- version 2.6.4-pl2
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Generation Time: Dec 28, 2005 at 02:58 AM
-- Server version: 4.0.25
-- PHP Version: 4.3.11
-- 
-- Database: `paulth40_Db`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `PTAddedApp`
-- 

CREATE TABLE `PTAddedApp` (
  `id` tinyint(3) unsigned NOT NULL auto_increment,
  `sid` tinyint(3) unsigned NOT NULL default '0',
  `date` date NOT NULL default '0000-00-00',
  `hours` decimal(5,2) unsigned NOT NULL default '1.00',
  `rate` decimal(6,2) unsigned default NULL,
  `comments` varchar(100) default NULL,
  `name` varchar(30) default NULL,
  PRIMARY KEY  (`id`)
) TYPE=MyISAM AUTO_INCREMENT=86 ;

-- 
-- Dumping data for table `PTAddedApp`
-- 

INSERT INTO `PTAddedApp` VALUES (1, 3, '2003-09-03', 1.00, 0.00, '', NULL);
INSERT INTO `PTAddedApp` VALUES (2, 3, '2003-09-09', 1.40, 0.00, '', NULL);
INSERT INTO `PTAddedApp` VALUES (3, 12, '2003-09-03', 0.00, 0.00, '', NULL);
INSERT INTO `PTAddedApp` VALUES (4, 13, '2003-09-09', 0.00, 0.00, '', NULL);
INSERT INTO `PTAddedApp` VALUES (5, 5, '2003-09-10', 0.00, 0.00, '', NULL);
INSERT INTO `PTAddedApp` VALUES (6, 12, '2003-09-18', 0.00, 0.00, '', NULL);
INSERT INTO `PTAddedApp` VALUES (7, 9, '2003-09-18', 0.00, 0.00, '', NULL);
INSERT INTO `PTAddedApp` VALUES (8, 10, '2003-09-18', 0.00, 0.00, '', NULL);
INSERT INTO `PTAddedApp` VALUES (9, 5, '2003-09-21', 2.00, 0.00, '', NULL);
INSERT INTO `PTAddedApp` VALUES (10, 1, '2003-09-21', 0.00, 0.00, '', NULL);
INSERT INTO `PTAddedApp` VALUES (11, 12, '2003-09-28', 0.00, 0.00, '', '');
INSERT INTO `PTAddedApp` VALUES (12, 11, '2003-10-15', 1.00, 0.00, '', '');
INSERT INTO `PTAddedApp` VALUES (13, 11, '2003-09-30', 1.00, 0.00, '', '');
INSERT INTO `PTAddedApp` VALUES (14, 1, '2003-10-02', 1.75, 0.00, '', '');
INSERT INTO `PTAddedApp` VALUES (15, 12, '2003-10-26', 2.20, 0.00, '', '');
INSERT INTO `PTAddedApp` VALUES (16, 12, '2003-10-30', 1.00, 0.00, '', '');
INSERT INTO `PTAddedApp` VALUES (17, 14, '2003-10-13', 1.00, 100.00, '', '');
INSERT INTO `PTAddedApp` VALUES (18, 14, '2003-10-14', 1.00, 100.00, '', '');
INSERT INTO `PTAddedApp` VALUES (19, 14, '2003-10-23', 1.00, 100.00, '', '');
INSERT INTO `PTAddedApp` VALUES (20, 4, '2003-10-29', 1.00, 100.00, '', 'Heath');
INSERT INTO `PTAddedApp` VALUES (21, 5, '2003-11-03', 0.00, 0.00, '', '');
INSERT INTO `PTAddedApp` VALUES (22, 12, '2003-11-11', 0.00, 0.00, '', '');
INSERT INTO `PTAddedApp` VALUES (23, 12, '2003-11-17', 1.33, 0.00, '', '');
INSERT INTO `PTAddedApp` VALUES (24, 10, '2003-11-11', 0.00, 0.00, '', '');
INSERT INTO `PTAddedApp` VALUES (25, 14, '2003-11-04', 0.00, 0.00, '', '');
INSERT INTO `PTAddedApp` VALUES (26, 14, '2003-11-21', 0.00, 0.00, '', '');
INSERT INTO `PTAddedApp` VALUES (27, 11, '2003-11-20', 0.00, 0.00, '', '');
INSERT INTO `PTAddedApp` VALUES (28, 2, '2003-12-04', 1.00, 0.00, '', '');
INSERT INTO `PTAddedApp` VALUES (29, 1, '2003-12-09', 2.50, 0.00, 'Mikey', '');
INSERT INTO `PTAddedApp` VALUES (30, 1, '2003-12-10', 1.50, 0.00, 'Mikey', '');
INSERT INTO `PTAddedApp` VALUES (31, 12, '2003-12-01', 1.00, 0.00, '', '');
INSERT INTO `PTAddedApp` VALUES (32, 12, '2003-12-04', 1.00, 0.00, '', '');
INSERT INTO `PTAddedApp` VALUES (33, 4, '2003-12-02', 1.00, 100.00, '', '');
INSERT INTO `PTAddedApp` VALUES (34, 4, '2003-12-01', 1.00, 100.00, '', '');
INSERT INTO `PTAddedApp` VALUES (35, 11, '2003-12-04', 0.00, 0.00, '', '');
INSERT INTO `PTAddedApp` VALUES (36, 5, '2004-01-13', 1.50, 0.00, '', '');
INSERT INTO `PTAddedApp` VALUES (37, 5, '2004-01-18', 1.00, 0.00, '', '');
INSERT INTO `PTAddedApp` VALUES (38, 5, '2004-01-19', 2.00, 0.00, '', '');
INSERT INTO `PTAddedApp` VALUES (39, 1, '2004-01-21', 1.25, 0.00, '', '');
INSERT INTO `PTAddedApp` VALUES (40, 12, '2004-01-05', 1.30, 0.00, '', '');
INSERT INTO `PTAddedApp` VALUES (41, 12, '2004-01-20', 1.75, 0.00, '', '');
INSERT INTO `PTAddedApp` VALUES (42, 12, '2004-01-22', 1.00, 0.00, '', '');
INSERT INTO `PTAddedApp` VALUES (43, 12, '2004-01-28', 1.00, 0.00, '', '');
INSERT INTO `PTAddedApp` VALUES (44, 3, '2004-01-13', 1.50, 0.00, '', '');
INSERT INTO `PTAddedApp` VALUES (45, 3, '2004-01-18', 1.00, 0.00, '', '');
INSERT INTO `PTAddedApp` VALUES (46, 3, '2004-01-19', 1.00, 0.00, '', '');
INSERT INTO `PTAddedApp` VALUES (47, 1, '2004-02-19', 0.00, 0.00, '', '');
INSERT INTO `PTAddedApp` VALUES (48, 12, '2004-02-09', 0.50, 0.00, '', '');
INSERT INTO `PTAddedApp` VALUES (49, 12, '2004-02-23', 0.50, 0.00, '', '');
INSERT INTO `PTAddedApp` VALUES (50, 3, '2004-02-19', 1.00, 0.00, '', '');
INSERT INTO `PTAddedApp` VALUES (51, 11, '2004-02-19', 0.00, 0.00, '', '');
INSERT INTO `PTAddedApp` VALUES (52, 12, '2004-03-24', 1.00, 0.00, '', 'gina D');
INSERT INTO `PTAddedApp` VALUES (53, 14, '2004-03-15', 1.00, 0.00, '', '');
INSERT INTO `PTAddedApp` VALUES (54, 11, '2004-04-29', 1.00, 0.00, '', '');
INSERT INTO `PTAddedApp` VALUES (55, 12, '2004-04-29', 1.00, 0.00, '', '');
INSERT INTO `PTAddedApp` VALUES (58, 11, '2004-05-06', 2.00, 0.00, '', '');
INSERT INTO `PTAddedApp` VALUES (59, 14, '2004-05-02', 1.00, 0.00, '', '');
INSERT INTO `PTAddedApp` VALUES (67, 2, '2004-05-17', 1.25, 0.00, '', '');
INSERT INTO `PTAddedApp` VALUES (63, 2, '2004-05-27', 1.00, 0.00, '', '');
INSERT INTO `PTAddedApp` VALUES (66, 4, '2004-05-27', 1.00, 100.00, '', '');
INSERT INTO `PTAddedApp` VALUES (68, 14, '2004-05-02', 1.00, 100.00, '', '');
INSERT INTO `PTAddedApp` VALUES (69, 2, '2004-06-07', 1.00, 0.00, '', '');
INSERT INTO `PTAddedApp` VALUES (70, 5, '2004-06-09', 2.00, 0.00, '', '');
INSERT INTO `PTAddedApp` VALUES (71, 1, '2004-06-10', 1.50, 0.00, '', '');
INSERT INTO `PTAddedApp` VALUES (72, 12, '2004-06-10', 1.00, 0.00, '', '');
INSERT INTO `PTAddedApp` VALUES (73, 12, '2004-06-08', 1.00, 0.00, '', '');
INSERT INTO `PTAddedApp` VALUES (74, 4, '2004-06-09', 2.00, 0.00, '', '');
INSERT INTO `PTAddedApp` VALUES (82, 3, '2004-06-07', 2.00, 90.00, '', '');
INSERT INTO `PTAddedApp` VALUES (83, 3, '2004-06-08', 1.00, 100.00, '', '');
INSERT INTO `PTAddedApp` VALUES (79, 16, '2004-06-08', 3.50, 0.00, '', '');
INSERT INTO `PTAddedApp` VALUES (80, 11, '2004-06-09', 1.00, 0.00, '', '');
INSERT INTO `PTAddedApp` VALUES (81, 11, '2004-06-10', 2.00, 0.00, '', '');
INSERT INTO `PTAddedApp` VALUES (84, 3, '2004-06-09', 1.00, 100.00, '', '');
INSERT INTO `PTAddedApp` VALUES (85, 5, '2004-06-01', 1.00, 100.00, 'No Show', '');

-- --------------------------------------------------------

-- 
-- Table structure for table `PTChangedApp`
-- 

CREATE TABLE `PTChangedApp` (
  `id` tinyint(3) unsigned NOT NULL auto_increment,
  `sid` tinyint(3) unsigned NOT NULL default '0',
  `date` date NOT NULL default '0000-00-00',
  `hours` decimal(5,2) unsigned default NULL,
  `rate` decimal(6,2) unsigned default NULL,
  `special` enum('late cancelation','no show','changed hours','special rate','rescheduling fee') NOT NULL default 'late cancelation',
  `comments` varchar(200) default NULL,
  PRIMARY KEY  (`id`)
) TYPE=MyISAM AUTO_INCREMENT=40 ;

-- 
-- Dumping data for table `PTChangedApp`
-- 

INSERT INTO `PTChangedApp` VALUES (2, 3, '2003-09-03', 1.00, 0.00, 'changed hours', '');
INSERT INTO `PTChangedApp` VALUES (3, 3, '2003-09-09', 1.25, 0.00, 'changed hours', '');
INSERT INTO `PTChangedApp` VALUES (4, 3, '2003-09-23', 1.30, 0.00, 'changed hours', '');
INSERT INTO `PTChangedApp` VALUES (5, 11, '2003-09-24', 1.50, 0.00, 'changed hours', '');
INSERT INTO `PTChangedApp` VALUES (12, 2, '2003-11-19', 1.50, 0.00, 'changed hours', '');
INSERT INTO `PTChangedApp` VALUES (10, 12, '2003-10-13', 2.25, 0.00, 'changed hours', '');
INSERT INTO `PTChangedApp` VALUES (11, 3, '2003-10-28', 1.00, 0.00, 'changed hours', '');
INSERT INTO `PTChangedApp` VALUES (13, 5, '2003-11-04', 0.50, 100.00, 'late cancelation', '');
INSERT INTO `PTChangedApp` VALUES (16, 4, '2003-12-01', 1.00, 100.00, '', '');
INSERT INTO `PTChangedApp` VALUES (15, 12, '2003-12-01', 1.50, 0.00, 'late cancelation', '');
INSERT INTO `PTChangedApp` VALUES (17, 11, '2003-12-09', 0.50, 0.00, '', '');
INSERT INTO `PTChangedApp` VALUES (18, 11, '2003-12-09', 0.50, 0.00, 'changed hours', '');
INSERT INTO `PTChangedApp` VALUES (20, 2, '2004-01-20', 1.25, 0.00, '', '');
INSERT INTO `PTChangedApp` VALUES (21, 2, '2004-02-11', 1.00, 0.00, 'changed hours', '');
INSERT INTO `PTChangedApp` VALUES (22, 3, '2004-02-10', 1.60, 0.00, 'changed hours', '');
INSERT INTO `PTChangedApp` VALUES (23, 14, '2004-02-22', 2.00, 0.00, 'changed hours', '');
INSERT INTO `PTChangedApp` VALUES (24, 12, '2004-03-09', 1.50, 0.00, 'changed hours', '');
INSERT INTO `PTChangedApp` VALUES (27, 1, '2004-03-03', 0.00, 0.00, 'late cancelation', '');
INSERT INTO `PTChangedApp` VALUES (28, 12, '2004-03-03', 0.00, 0.00, 'late cancelation', '');
INSERT INTO `PTChangedApp` VALUES (29, 11, '2004-03-23', 1.25, 0.00, 'changed hours', '');
INSERT INTO `PTChangedApp` VALUES (30, 11, '2004-03-24', 1.50, 0.00, 'changed hours', '');
INSERT INTO `PTChangedApp` VALUES (31, 5, '2004-03-15', 0.00, 0.00, 'late cancelation', '');
INSERT INTO `PTChangedApp` VALUES (32, 5, '2004-03-03', 0.00, 0.00, 'late cancelation', '');
INSERT INTO `PTChangedApp` VALUES (33, 4, '2004-05-11', 2.25, 0.00, 'changed hours', '');
INSERT INTO `PTChangedApp` VALUES (34, 4, '2004-05-04', 2.25, 0.00, 'changed hours', '');
INSERT INTO `PTChangedApp` VALUES (35, 4, '2004-05-18', 2.10, 0.00, 'changed hours', '');
INSERT INTO `PTChangedApp` VALUES (36, 1, '2004-05-12', 1.75, 0.00, 'changed hours', '');
INSERT INTO `PTChangedApp` VALUES (38, 5, '2004-06-01', 0.00, 0.00, 'no show', '');
INSERT INTO `PTChangedApp` VALUES (39, 1, '2004-06-02', 0.00, 0.00, 'late cancelation', '');

-- --------------------------------------------------------

-- 
-- Table structure for table `PTHomeWork1`
-- 

CREATE TABLE `PTHomeWork1` (
  `id` smallint(5) unsigned NOT NULL auto_increment,
  `sid` tinyint(3) unsigned NOT NULL default '0',
  `hwid` varchar(15) NOT NULL default '',
  `start_date` date NOT NULL default '0000-00-00',
  `day_of_week` varchar(15) default NULL,
  `start_time` time NOT NULL default '00:00:00',
  `end_time` time default NULL,
  `set_size` tinyint(3) unsigned NOT NULL default '0',
  `set_num` tinyint(3) unsigned NOT NULL default '0',
  `tot_probs` tinyint(3) unsigned default NULL,
  `help_count` tinyint(3) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  FULLTEXT KEY `hwid` (`hwid`)
) TYPE=MyISAM COMMENT='this table saves information on a students work' AUTO_INCREMENT=684 ;

-- 
-- Dumping data for table `PTHomeWork1`
-- 

INSERT INTO `PTHomeWork1` VALUES (1, 10, 'numtimestables', '2003-10-21', 'Tuesday', '19:42:50', '19:58:47', 15, 6, 31, 16);
INSERT INTO `PTHomeWork1` VALUES (2, 10, 'numtimestables', '2003-10-21', 'Tuesday', '19:58:47', '20:01:32', 15, 9, 15, 2);
INSERT INTO `PTHomeWork1` VALUES (3, 10, 'numtimestables', '2003-10-21', 'Tuesday', '20:01:32', '20:06:52', 15, 8, 15, 0);
INSERT INTO `PTHomeWork1` VALUES (4, 10, 'numtimestables', '2003-10-21', 'Tuesday', '20:06:52', NULL, 15, 4, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (5, 10, 'numtimestables', '2003-10-23', 'Thursday', '14:40:03', '14:44:09', 15, 8, 15, 0);
INSERT INTO `PTHomeWork1` VALUES (6, 10, 'numtimestables', '2003-10-23', 'Thursday', '14:44:09', '14:49:33', 15, 4, 15, 0);
INSERT INTO `PTHomeWork1` VALUES (7, 10, 'numtimestables', '2003-10-23', 'Thursday', '14:49:33', '14:54:49', 15, 7, 23, 0);
INSERT INTO `PTHomeWork1` VALUES (8, 10, 'numtimestables', '2003-10-23', 'Thursday', '14:54:49', '15:03:10', 15, 6, 15, 0);
INSERT INTO `PTHomeWork1` VALUES (9, 10, 'numtimestables', '2003-10-23', 'Thursday', '15:03:10', NULL, 15, 9, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (10, 10, 'numtimestables', '2003-10-27', 'Monday', '16:46:59', '16:49:04', 15, 7, 15, 0);
INSERT INTO `PTHomeWork1` VALUES (11, 10, 'numtimestables', '2003-10-27', 'Monday', '16:49:04', '16:53:30', 15, 6, 20, 1);
INSERT INTO `PTHomeWork1` VALUES (12, 10, 'numtimestables', '2003-10-27', 'Monday', '16:53:30', '16:55:16', 15, 3, 15, 0);
INSERT INTO `PTHomeWork1` VALUES (13, 10, 'numtimestables', '2003-10-27', 'Monday', '16:55:16', '17:02:14', 15, 3, 15, 0);
INSERT INTO `PTHomeWork1` VALUES (14, 10, 'numtimestables', '2003-10-27', 'Monday', '17:02:14', '17:03:47', 15, 2, 15, 0);
INSERT INTO `PTHomeWork1` VALUES (15, 10, 'numtimestables', '2003-10-27', 'Monday', '17:03:47', '17:05:18', 15, 2, 15, 0);
INSERT INTO `PTHomeWork1` VALUES (16, 10, 'numtimestables', '2003-10-27', 'Monday', '17:05:18', '17:09:17', 15, 4, 18, 0);
INSERT INTO `PTHomeWork1` VALUES (17, 10, 'numtimestables', '2003-10-27', 'Monday', '17:09:17', NULL, 15, 8, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (18, 10, 'numtimestables', '2003-10-27', 'Monday', '17:11:05', '17:20:37', 15, 6, 26, 2);
INSERT INTO `PTHomeWork1` VALUES (19, 10, 'numtimestables', '2003-10-27', 'Monday', '17:17:32', NULL, 15, 7, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (20, 10, 'numtimestables', '2003-10-27', 'Monday', '17:18:31', NULL, 15, 3, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (21, 10, 'numtimestables', '2003-10-27', 'Monday', '17:20:37', '17:22:01', 15, 2, 15, 0);
INSERT INTO `PTHomeWork1` VALUES (22, 10, 'numtimestables', '2003-10-27', 'Monday', '17:22:01', '17:24:13', 15, 7, 15, 0);
INSERT INTO `PTHomeWork1` VALUES (23, 10, 'numtimestables', '2003-10-27', 'Monday', '17:24:13', '17:28:32', 15, 4, 20, 0);
INSERT INTO `PTHomeWork1` VALUES (24, 10, 'numtimestables', '2003-10-27', 'Monday', '17:28:32', '17:31:17', 15, 5, 15, 0);
INSERT INTO `PTHomeWork1` VALUES (25, 10, 'numtimestables', '2003-10-27', 'Monday', '17:31:17', '17:35:16', 15, 5, 16, 0);
INSERT INTO `PTHomeWork1` VALUES (26, 10, 'numtimestables', '2003-10-27', 'Monday', '17:35:16', NULL, 15, 5, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (27, 10, 'numtimestables', '2003-10-29', 'Wednesday', '18:17:04', '18:19:38', 15, 7, 15, 1);
INSERT INTO `PTHomeWork1` VALUES (28, 10, 'numtimestables', '2003-10-29', 'Wednesday', '18:19:38', '18:22:03', 15, 2, 29, 0);
INSERT INTO `PTHomeWork1` VALUES (29, 10, 'numtimestables', '2003-10-29', 'Wednesday', '18:22:03', '18:29:04', 15, 6, 15, 0);
INSERT INTO `PTHomeWork1` VALUES (30, 10, 'numtimestables', '2003-10-29', 'Wednesday', '18:29:04', '18:34:15', 15, 5, 15, 1);
INSERT INTO `PTHomeWork1` VALUES (31, 10, 'numtimestables', '2003-10-29', 'Wednesday', '18:34:15', '18:39:27', 15, 8, 15, 1);
INSERT INTO `PTHomeWork1` VALUES (32, 10, 'numtimestables', '2003-10-29', 'Wednesday', '18:39:27', NULL, 15, 5, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (33, 10, 'numtimestables', '2003-11-03', 'Monday', '16:46:20', '16:51:52', 15, 6, 15, 1);
INSERT INTO `PTHomeWork1` VALUES (34, 10, 'numtimestables', '2003-11-03', 'Monday', '16:51:52', '16:57:42', 15, 8, 26, 7);
INSERT INTO `PTHomeWork1` VALUES (35, 10, 'numtimestables', '2003-11-03', 'Monday', '16:57:42', NULL, 15, 8, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (36, 10, 'numtimestables', '2003-11-03', 'Monday', '16:59:24', NULL, 15, 7, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (37, 10, 'numtimestables', '2003-11-03', 'Monday', '16:59:39', '17:04:07', 15, 3, 15, 0);
INSERT INTO `PTHomeWork1` VALUES (38, 10, 'numtimestables', '2003-11-03', 'Monday', '17:04:07', '17:07:32', 15, 4, 15, 1);
INSERT INTO `PTHomeWork1` VALUES (39, 10, 'numtimestables', '2003-11-03', 'Monday', '17:07:32', '17:12:36', 15, 7, 15, 3);
INSERT INTO `PTHomeWork1` VALUES (40, 10, 'numtimestables', '2003-11-03', 'Monday', '17:12:36', '17:16:55', 15, 8, 15, 6);
INSERT INTO `PTHomeWork1` VALUES (41, 10, 'numtimestables', '2003-11-03', 'Monday', '17:16:55', '17:24:23', 15, 4, 15, 1);
INSERT INTO `PTHomeWork1` VALUES (42, 10, 'numtimestables', '2003-11-03', 'Monday', '17:24:23', NULL, 15, 8, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (43, 10, 'numtimestables', '2003-11-03', 'Monday', '17:29:46', '17:33:43', 15, 5, 16, 0);
INSERT INTO `PTHomeWork1` VALUES (44, 10, 'numtimestables', '2003-11-03', 'Monday', '17:33:43', NULL, 15, 8, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (45, 10, 'numtimestables', '2003-11-06', 'Thursday', '18:24:38', '18:33:33', 15, 8, 15, 0);
INSERT INTO `PTHomeWork1` VALUES (46, 10, 'numtimestables', '2003-11-06', 'Thursday', '18:33:33', '18:37:54', 15, 2, 21, 1);
INSERT INTO `PTHomeWork1` VALUES (47, 10, 'numtimestables', '2003-11-06', 'Thursday', '18:37:54', '18:45:32', 15, 4, 15, 2);
INSERT INTO `PTHomeWork1` VALUES (48, 10, 'numtimestables', '2003-11-06', 'Thursday', '18:45:32', NULL, 15, 6, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (49, 10, 'numtimestables', '2003-11-10', 'Monday', '21:27:18', '21:30:53', 15, 3, 15, 0);
INSERT INTO `PTHomeWork1` VALUES (50, 10, 'numtimestables', '2003-11-10', 'Monday', '21:30:53', '21:31:53', 15, 2, 15, 0);
INSERT INTO `PTHomeWork1` VALUES (51, 10, 'numtimestables', '2003-11-10', 'Monday', '21:31:53', '21:47:42', 15, 5, 34, 0);
INSERT INTO `PTHomeWork1` VALUES (52, 10, 'numtimestables', '2003-11-10', 'Monday', '21:47:42', NULL, 15, 7, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (53, 10, 'numtimestables', '2003-11-17', 'Monday', '17:37:14', '17:39:13', 15, 5, 15, 0);
INSERT INTO `PTHomeWork1` VALUES (54, 10, 'numtimestables', '2003-11-17', 'Monday', '17:39:13', '17:43:19', 15, 8, 15, 2);
INSERT INTO `PTHomeWork1` VALUES (55, 10, 'numtimestables', '2003-11-17', 'Monday', '17:43:19', '17:45:53', 15, 4, 15, 1);
INSERT INTO `PTHomeWork1` VALUES (56, 10, 'numtimestables', '2003-11-17', 'Monday', '17:45:53', '17:55:22', 15, 2, 15, 0);
INSERT INTO `PTHomeWork1` VALUES (57, 10, 'numtimestables', '2003-11-17', 'Monday', '17:55:22', '17:57:51', 15, 5, 15, 0);
INSERT INTO `PTHomeWork1` VALUES (58, 10, 'numtimestables', '2003-11-17', 'Monday', '17:57:51', NULL, 15, 4, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (59, 10, 'numtimestables', '2003-11-17', 'Monday', '18:05:08', NULL, 15, 7, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (60, 10, 'numtimestables', '2003-11-17', 'Monday', '18:34:15', NULL, 15, 7, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (61, 10, 'numtimestables', '2003-11-17', 'Monday', '18:35:02', NULL, 15, 7, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (62, 10, 'numtimestables', '2003-11-17', 'Monday', '18:35:06', NULL, 15, 2, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (63, 10, 'numtimestables', '2003-11-17', 'Monday', '18:35:11', NULL, 15, 9, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (64, 10, 'numtimestables', '2003-11-17', 'Monday', '18:35:14', NULL, 15, 2, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (65, 10, 'numtimestables', '2003-11-17', 'Monday', '18:35:15', NULL, 15, 9, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (66, 10, 'numtimestables', '2003-11-20', 'Thursday', '15:49:23', '15:59:49', 15, 3, 21, 0);
INSERT INTO `PTHomeWork1` VALUES (67, 10, 'numtimestables', '2003-11-20', 'Thursday', '15:59:49', '16:03:31', 15, 2, 15, 0);
INSERT INTO `PTHomeWork1` VALUES (68, 10, 'numtimestables', '2003-11-20', 'Thursday', '16:03:31', '16:11:35', 15, 7, 15, 0);
INSERT INTO `PTHomeWork1` VALUES (69, 10, 'numtimestables', '2003-11-20', 'Thursday', '16:11:35', NULL, 15, 9, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (70, 10, 'numtimestables', '2003-11-24', 'Monday', '10:24:59', NULL, 15, 8, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (71, 10, 'numtimestables', '2003-11-24', 'Monday', '10:28:41', NULL, 15, 5, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (72, 10, 'numtimestables', '2003-11-24', 'Monday', '10:28:43', NULL, 15, 7, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (73, 10, 'numtimestables', '2003-11-30', 'Sunday', '07:12:01', NULL, 15, 6, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (74, 10, 'numtimestables', '2003-11-30', 'Sunday', '12:06:52', NULL, 15, 6, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (75, 10, 'numtimestables', '2003-11-30', 'Sunday', '12:06:58', NULL, 15, 9, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (76, 10, 'numtimestables', '2003-11-30', 'Sunday', '12:06:59', NULL, 15, 8, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (77, 10, 'numtimestables', '2003-11-30', 'Sunday', '12:07:01', '12:10:05', 15, 3, 15, 0);
INSERT INTO `PTHomeWork1` VALUES (78, 10, 'numtimestables', '2003-11-30', 'Sunday', '12:10:05', '12:35:11', 15, 4, 48, 2);
INSERT INTO `PTHomeWork1` VALUES (79, 10, 'numtimestables', '2003-11-30', 'Sunday', '12:35:11', NULL, 15, 6, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (80, 10, 'numtimestables', '2003-12-01', 'Monday', '17:27:22', '17:31:12', 15, 4, 15, 2);
INSERT INTO `PTHomeWork1` VALUES (81, 10, 'numtimestables', '2003-12-01', 'Monday', '17:31:12', '17:35:33', 15, 8, 16, 14);
INSERT INTO `PTHomeWork1` VALUES (82, 10, 'numtimestables', '2003-12-01', 'Monday', '17:35:33', '17:37:03', 15, 2, 15, 0);
INSERT INTO `PTHomeWork1` VALUES (83, 10, 'numtimestables', '2003-12-01', 'Monday', '17:37:03', '17:39:37', 15, 5, 15, 2);
INSERT INTO `PTHomeWork1` VALUES (84, 10, 'numtimestables', '2003-12-01', 'Monday', '17:39:37', '17:52:43', 15, 4, 15, 4);
INSERT INTO `PTHomeWork1` VALUES (85, 10, 'numtimestables', '2003-12-01', 'Monday', '17:52:43', NULL, 15, 6, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (86, 10, 'numtimestables', '2003-12-01', 'Monday', '17:54:17', '18:00:21', 15, 7, 15, 5);
INSERT INTO `PTHomeWork1` VALUES (87, 10, 'numtimestables', '2003-12-01', 'Monday', '18:00:21', '18:03:58', 15, 6, 15, 3);
INSERT INTO `PTHomeWork1` VALUES (88, 10, 'numtimestables', '2003-12-01', 'Monday', '18:03:58', NULL, 15, 2, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (89, 10, 'numtimestables', '2003-12-04', 'Thursday', '17:34:53', NULL, 15, 5, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (90, 10, 'numtimestables', '2003-12-04', 'Thursday', '18:55:35', NULL, 15, 7, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (91, 10, 'numtimestables', '2003-12-04', 'Thursday', '18:55:39', NULL, 15, 9, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (92, 10, 'numtimestables', '2003-12-04', 'Thursday', '18:55:40', '18:57:01', 15, 2, 15, 0);
INSERT INTO `PTHomeWork1` VALUES (93, 10, 'numtimestables', '2003-12-04', 'Thursday', '18:57:01', '19:15:44', 15, 6, 16, 3);
INSERT INTO `PTHomeWork1` VALUES (94, 10, 'numtimestables', '2003-12-04', 'Thursday', '19:15:44', NULL, 15, 4, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (95, 10, 'numtimestables', '2003-12-06', 'Saturday', '10:44:58', NULL, 15, 3, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (96, 10, 'numtimestables', '2003-12-08', 'Monday', '17:42:43', '17:43:56', 15, 2, 15, 0);
INSERT INTO `PTHomeWork1` VALUES (97, 10, 'numtimestables', '2003-12-08', 'Monday', '17:43:56', NULL, 15, 6, NULL, 5);
INSERT INTO `PTHomeWork1` VALUES (98, 10, 'numtimestables', '2003-12-09', 'Tuesday', '18:00:01', '18:04:04', 15, 2, 15, 1);
INSERT INTO `PTHomeWork1` VALUES (99, 10, 'numtimestables', '2003-12-09', 'Tuesday', '18:04:04', '18:13:00', 15, 6, 15, 10);
INSERT INTO `PTHomeWork1` VALUES (100, 10, 'numtimestables', '2003-12-09', 'Tuesday', '18:13:00', '18:15:41', 15, 3, 15, 0);
INSERT INTO `PTHomeWork1` VALUES (101, 10, 'numtimestables', '2003-12-09', 'Tuesday', '18:15:41', '18:23:17', 15, 8, 18, 9);
INSERT INTO `PTHomeWork1` VALUES (102, 10, 'numtimestables', '2003-12-09', 'Tuesday', '18:23:17', NULL, 15, 7, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (103, 10, 'numtimestables', '2003-12-12', 'Friday', '16:49:11', NULL, 15, 3, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (104, 10, 'numtimestables', '2003-12-15', 'Monday', '08:17:16', NULL, 15, 4, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (105, 10, 'numtimestables', '2003-12-15', 'Monday', '18:10:39', NULL, 15, 6, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (106, 10, 'numtimestables', '2003-12-15', 'Monday', '20:30:47', NULL, 15, 2, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (107, 10, 'numtimestables', '2003-12-16', 'Tuesday', '18:32:36', NULL, 15, 7, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (108, 10, 'numtimestables', '2003-12-17', 'Wednesday', '12:21:48', NULL, 15, 5, NULL, 2);
INSERT INTO `PTHomeWork1` VALUES (109, 10, 'numtimestables', '2003-12-17', 'Wednesday', '12:22:39', NULL, 15, 3, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (110, 10, 'numtimestables', '2003-12-17', 'Wednesday', '13:19:41', NULL, 15, 9, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (111, 10, 'numtimestables', '2003-12-19', 'Friday', '22:01:11', NULL, 15, 4, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (112, 10, 'numtimestables', '2003-12-21', 'Sunday', '12:27:55', '12:28:41', 15, 2, 15, 0);
INSERT INTO `PTHomeWork1` VALUES (113, 10, 'numtimestables', '2003-12-21', 'Sunday', '12:28:41', '12:29:10', 15, 3, 15, 0);
INSERT INTO `PTHomeWork1` VALUES (114, 10, 'numtimestables', '2003-12-21', 'Sunday', '12:29:10', NULL, 15, 4, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (115, 10, 'numtimestables', '2003-12-22', 'Monday', '01:37:55', '01:38:32', 15, 3, 15, 0);
INSERT INTO `PTHomeWork1` VALUES (116, 10, 'numtimestables', '2003-12-22', 'Monday', '01:38:32', NULL, 15, 4, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (117, 10, 'numtimestables', '2003-12-22', 'Monday', '14:53:19', NULL, 15, 3, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (118, 10, 'numtimestables', '2003-12-22', 'Monday', '14:53:20', NULL, 15, 9, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (119, 10, 'numtimestables', '2003-12-25', 'Thursday', '22:12:41', NULL, 15, 6, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (120, 10, 'numtimestables', '2003-12-28', 'Sunday', '10:57:55', NULL, 15, 7, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (121, 10, 'numtimestables', '2004-01-05', 'Monday', '17:07:09', NULL, 15, 9, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (122, 10, 'numtimestables', '2004-01-08', 'Thursday', '12:21:15', NULL, 15, 5, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (123, 10, 'numtimestables', '2004-01-09', 'Friday', '23:02:47', NULL, 15, 6, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (124, 10, 'numtimestables', '2004-01-09', 'Friday', '23:03:02', NULL, 15, 7, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (125, 10, 'numtimestables', '2004-01-12', 'Monday', '13:05:04', NULL, 15, 9, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (126, 10, 'numtimestables', '2004-01-13', 'Tuesday', '10:11:39', NULL, 15, 2, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (127, 10, 'numtimestables', '2004-01-13', 'Tuesday', '10:11:55', NULL, 15, 3, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (128, 10, 'numtimestables', '2004-01-17', 'Saturday', '04:47:02', NULL, 15, 6, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (129, 10, 'numtimestables', '2004-01-22', 'Thursday', '18:22:27', '18:24:38', 15, 4, 15, 0);
INSERT INTO `PTHomeWork1` VALUES (130, 10, 'numtimestables', '2004-01-22', 'Thursday', '18:24:38', NULL, 15, 2, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (131, 10, 'numtimestables', '2004-01-22', 'Thursday', '18:26:48', NULL, 15, 3, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (132, 10, 'numtimestables', '2004-01-22', 'Thursday', '18:26:55', NULL, 15, 8, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (133, 10, 'numtimestables', '2004-01-22', 'Thursday', '18:26:57', NULL, 15, 7, NULL, 2);
INSERT INTO `PTHomeWork1` VALUES (134, 10, 'numtimestables', '2004-01-22', 'Thursday', '18:32:23', NULL, 15, 3, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (135, 10, 'numtimestables', '2004-01-22', 'Thursday', '18:32:26', NULL, 15, 7, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (136, 10, 'numtimestables', '2004-01-22', 'Thursday', '18:32:27', NULL, 15, 6, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (137, 10, 'numtimestables', '2004-01-22', 'Thursday', '18:32:28', NULL, 15, 8, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (138, 10, 'numtimestables', '2004-01-22', 'Thursday', '18:32:29', NULL, 15, 9, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (139, 10, 'numtimestables', '2004-01-22', 'Thursday', '18:32:30', NULL, 15, 7, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (140, 10, 'numtimestables', '2004-01-22', 'Thursday', '18:32:31', NULL, 15, 8, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (141, 10, 'numtimestables', '2004-01-22', 'Thursday', '18:32:32', NULL, 15, 6, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (142, 10, 'numtimestables', '2004-01-22', 'Thursday', '18:32:33', NULL, 15, 4, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (143, 10, 'numtimestables', '2004-01-22', 'Thursday', '18:32:34', '18:40:15', 15, 6, 21, 7);
INSERT INTO `PTHomeWork1` VALUES (144, 10, 'numtimestables', '2004-01-22', 'Thursday', '18:40:15', NULL, 15, 8, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (145, 10, 'numtimestables', '2004-01-22', 'Thursday', '18:57:37', NULL, 15, 8, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (146, 10, 'numtimestables', '2004-01-24', 'Saturday', '13:54:19', '13:55:59', 15, 7, 15, 0);
INSERT INTO `PTHomeWork1` VALUES (147, 10, 'numtimestables', '2004-01-24', 'Saturday', '13:55:59', NULL, 15, 5, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (148, 10, 'numtimestables', '2004-01-26', 'Monday', '13:35:25', NULL, 15, 6, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (149, 10, 'numtimestables', '2004-01-30', 'Friday', '18:27:05', NULL, 15, 4, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (150, 10, 'numtimestables', '2004-02-01', 'Sunday', '15:49:29', NULL, 15, 5, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (151, 10, 'numtimestables', '2004-02-02', 'Monday', '18:35:41', NULL, 15, 9, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (152, 10, 'numtimestables', '2004-02-02', 'Monday', '20:43:54', '20:44:26', 15, 2, 15, 0);
INSERT INTO `PTHomeWork1` VALUES (153, 10, 'numtimestables', '2004-02-02', 'Monday', '20:44:26', NULL, 15, 3, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (154, 10, 'numtimestables', '2004-02-18', 'Wednesday', '09:30:15', NULL, 15, 8, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (155, 10, 'numtimestables', '2004-02-18', 'Wednesday', '10:22:03', NULL, 15, 4, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (156, 10, 'numtimestables', '2004-02-18', 'Wednesday', '10:22:11', NULL, 15, 6, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (157, 10, 'numtimestables', '2004-02-26', 'Thursday', '20:24:01', NULL, 15, 3, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (158, 10, 'numtimestables', '2004-03-03', 'Wednesday', '20:27:26', NULL, 15, 2, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (159, 10, 'numtimestables', '2004-03-04', 'Thursday', '13:44:18', NULL, 15, 2, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (160, 10, 'numtimestables', '2004-03-05', 'Friday', '21:42:10', NULL, 15, 6, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (161, 10, 'numtimestables', '2004-03-05', 'Friday', '23:12:30', NULL, 15, 6, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (162, 10, 'numtimestables', '2004-03-08', 'Monday', '21:27:03', NULL, 15, 6, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (163, 10, 'numtimestables', '2004-03-10', 'Wednesday', '12:20:04', NULL, 15, 5, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (164, 10, 'numtimestables', '2004-03-10', 'Wednesday', '17:10:54', NULL, 15, 6, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (165, 10, 'numtimestables', '2004-03-10', 'Wednesday', '21:55:45', NULL, 15, 3, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (166, 10, 'numtimestables', '2004-03-12', 'Friday', '09:05:01', NULL, 15, 4, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (167, 10, 'numtimestables', '2004-03-12', 'Friday', '10:22:07', NULL, 15, 8, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (168, 10, 'numtimestables', '2004-03-14', 'Sunday', '08:03:07', NULL, 15, 6, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (169, 10, 'numtimestables', '2004-03-14', 'Sunday', '08:03:09', NULL, 15, 6, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (170, 10, 'numtimestables', '2004-03-14', 'Sunday', '11:11:49', NULL, 15, 9, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (171, 10, 'numtimestables', '2004-03-15', 'Monday', '13:47:30', NULL, 15, 7, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (172, 10, 'numtimestables', '2004-03-16', 'Tuesday', '14:19:13', NULL, 15, 7, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (173, 10, 'numtimestables', '2004-03-17', 'Wednesday', '16:53:04', NULL, 15, 9, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (174, 10, 'numtimestables', '2004-03-20', 'Saturday', '23:12:45', NULL, 15, 3, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (175, 10, 'numtimestables', '2004-03-23', 'Tuesday', '08:37:19', NULL, 15, 3, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (176, 10, 'numtimestables', '2004-03-26', 'Friday', '22:11:35', NULL, 15, 4, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (177, 10, 'numtimestables', '2004-03-27', 'Saturday', '18:23:28', NULL, 15, 8, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (178, 10, 'numtimestables', '2004-03-27', 'Saturday', '22:53:27', NULL, 15, 7, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (179, 10, 'numtimestables', '2004-03-29', 'Monday', '11:41:59', NULL, 15, 7, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (180, 10, 'numtimestables', '2004-03-31', 'Wednesday', '23:12:42', NULL, 15, 9, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (181, 10, 'numtimestables', '2004-04-01', 'Thursday', '12:45:21', '12:45:58', 15, 8, 15, 0);
INSERT INTO `PTHomeWork1` VALUES (182, 10, 'numtimestables', '2004-04-01', 'Thursday', '12:45:58', NULL, 15, 4, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (183, 10, 'numtimestables', '2004-04-01', 'Thursday', '17:51:35', NULL, 15, 4, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (184, 10, 'numtimestables', '2004-04-01', 'Thursday', '20:49:15', NULL, 15, 9, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (185, 10, 'numtimestables', '2004-04-03', 'Saturday', '00:52:55', NULL, 15, 2, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (186, 10, 'numtimestables', '2004-04-04', 'Sunday', '05:52:41', NULL, 15, 7, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (187, 10, 'numtimestables', '2004-04-05', 'Monday', '02:10:56', NULL, 15, 2, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (188, 10, 'numtimestables', '2004-04-07', 'Wednesday', '06:09:34', NULL, 15, 5, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (189, 10, 'numtimestables', '2004-04-07', 'Wednesday', '10:17:07', NULL, 15, 8, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (190, 10, 'numtimestables', '2004-04-07', 'Wednesday', '15:30:12', NULL, 15, 9, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (191, 10, 'numtimestables', '2004-04-07', 'Wednesday', '18:57:53', NULL, 15, 5, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (192, 10, 'numtimestables', '2004-04-08', 'Thursday', '11:11:49', NULL, 15, 3, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (193, 10, 'numtimestables', '2004-04-08', 'Thursday', '11:19:08', NULL, 15, 8, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (194, 10, 'numtimestables', '2004-04-10', 'Saturday', '21:50:07', NULL, 15, 8, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (195, 10, 'numtimestables', '2004-04-13', 'Tuesday', '13:03:42', NULL, 15, 4, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (196, 10, 'numtimestables', '2004-04-15', 'Thursday', '05:18:26', NULL, 15, 4, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (197, 10, 'numtimestables', '2004-04-15', 'Thursday', '05:18:32', NULL, 15, 8, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (198, 10, 'numtimestables', '2004-04-15', 'Thursday', '07:45:56', NULL, 15, 2, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (199, 10, 'numtimestables', '2004-04-16', 'Friday', '08:28:09', NULL, 15, 4, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (200, 10, 'numtimestables', '2004-04-17', 'Saturday', '18:12:47', NULL, 15, 2, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (201, 10, 'numtimestables', '2004-04-17', 'Saturday', '18:13:45', NULL, 15, 4, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (202, 10, 'numtimestables', '2004-04-20', 'Tuesday', '02:11:27', NULL, 15, 7, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (203, 10, 'numtimestables', '2004-04-25', 'Sunday', '20:52:58', '20:53:43', 15, 3, 15, 0);
INSERT INTO `PTHomeWork1` VALUES (204, 10, 'numtimestables', '2004-04-25', 'Sunday', '20:53:43', '20:54:55', 15, 8, 15, 2);
INSERT INTO `PTHomeWork1` VALUES (205, 10, 'numtimestables', '2004-04-25', 'Sunday', '20:54:55', '20:55:38', 15, 5, 15, 0);
INSERT INTO `PTHomeWork1` VALUES (206, 10, 'numtimestables', '2004-04-25', 'Sunday', '20:55:38', '20:57:02', 15, 9, 15, 1);
INSERT INTO `PTHomeWork1` VALUES (207, 10, 'numtimestables', '2004-04-25', 'Sunday', '20:57:02', NULL, 15, 8, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (208, 10, 'numtimestables', '2004-04-26', 'Monday', '09:44:29', NULL, 15, 4, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (209, 10, 'numtimestables', '2004-04-27', 'Tuesday', '14:22:07', NULL, 15, 9, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (210, 10, 'numtimestables', '2004-04-27', 'Tuesday', '14:30:43', NULL, 15, 3, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (211, 10, 'numtimestables', '2004-05-03', 'Monday', '14:47:40', NULL, 15, 2, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (212, 10, 'numtimestables', '2004-05-05', 'Wednesday', '02:11:31', NULL, 15, 6, NULL, 41);
INSERT INTO `PTHomeWork1` VALUES (213, 10, 'numtimestables', '2004-05-05', 'Wednesday', '11:05:31', NULL, 15, 7, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (214, 10, 'numtimestables', '2004-05-21', 'Friday', '12:10:19', '12:11:17', 15, 2, 15, 0);
INSERT INTO `PTHomeWork1` VALUES (215, 10, 'numtimestables', '2004-05-21', 'Friday', '12:11:17', '12:12:07', 15, 4, 15, 0);
INSERT INTO `PTHomeWork1` VALUES (216, 10, 'numtimestables', '2004-05-21', 'Friday', '12:12:07', NULL, 15, 8, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (217, 10, 'numtimestables', '2004-05-21', 'Friday', '19:40:12', NULL, 15, 5, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (218, 10, 'numtimestables', '2004-05-23', 'Sunday', '16:36:51', NULL, 15, 3, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (219, 10, 'numtimestables', '2004-05-24', 'Monday', '12:08:23', NULL, 15, 6, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (220, 10, 'numtimestables', '2004-05-24', 'Monday', '12:33:54', '12:41:23', 15, 9, 15, 0);
INSERT INTO `PTHomeWork1` VALUES (221, 10, 'numtimestables', '2004-05-24', 'Monday', '12:41:23', NULL, 15, 5, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (222, 10, 'numtimestables', '2004-05-24', 'Monday', '12:44:18', NULL, 15, 5, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (223, 10, 'numtimestables', '2004-05-24', 'Monday', '15:55:18', NULL, 15, 9, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (224, 10, 'numtimestables', '2004-06-09', 'Wednesday', '03:06:54', NULL, 15, 3, NULL, 37);
INSERT INTO `PTHomeWork1` VALUES (225, 10, 'numtimestables', '2004-06-09', 'Wednesday', '04:38:49', NULL, 15, 2, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (226, 10, 'numtimestables', '2004-06-10', 'Thursday', '09:37:38', NULL, 15, 7, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (227, 10, 'numtimestables', '2004-06-12', 'Saturday', '13:24:31', NULL, 15, 5, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (228, 10, 'numtimestables', '2004-06-12', 'Saturday', '13:25:07', NULL, 15, 3, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (229, 10, 'numtimestables', '2004-06-14', 'Monday', '19:17:38', NULL, 15, 8, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (230, 10, 'numtimestables', '2004-06-19', 'Saturday', '22:31:30', NULL, 15, 6, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (231, 10, 'numtimestables', '2004-06-22', 'Tuesday', '15:35:49', NULL, 15, 5, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (232, 10, 'numtimestables', '2004-06-24', 'Thursday', '03:16:02', NULL, 15, 8, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (233, 10, 'numtimestables', '2004-06-24', 'Thursday', '03:37:22', NULL, 15, 3, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (234, 10, 'numtimestables', '2004-06-24', 'Thursday', '16:10:32', NULL, 15, 8, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (235, 10, 'numtimestables', '2004-06-25', 'Friday', '14:12:01', NULL, 15, 8, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (236, 10, 'numtimestables', '2004-06-27', 'Sunday', '19:11:38', NULL, 15, 5, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (237, 10, 'numtimestables', '2004-06-27', 'Sunday', '19:13:49', NULL, 15, 3, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (238, 10, 'numtimestables', '2004-06-29', 'Tuesday', '04:04:25', NULL, 15, 2, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (239, 10, 'numtimestables', '2004-07-01', 'Thursday', '16:08:22', NULL, 15, 4, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (240, 10, 'numtimestables', '2004-07-02', 'Friday', '04:47:11', NULL, 15, 5, NULL, 2);
INSERT INTO `PTHomeWork1` VALUES (241, 10, 'numtimestables', '2004-07-04', 'Sunday', '09:01:06', NULL, 15, 5, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (242, 10, 'numtimestables', '2004-07-07', 'Wednesday', '20:32:50', NULL, 15, 8, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (243, 10, 'numtimestables', '2004-07-09', 'Friday', '03:38:28', NULL, 15, 2, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (244, 10, 'numtimestables', '2004-07-09', 'Friday', '05:27:00', NULL, 15, 5, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (245, 10, 'numtimestables', '2004-07-10', 'Saturday', '02:28:05', NULL, 15, 9, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (246, 10, 'numtimestables', '2004-07-11', 'Sunday', '01:47:28', NULL, 15, 5, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (247, 10, 'numtimestables', '2004-07-11', 'Sunday', '14:24:43', NULL, 15, 8, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (248, 10, 'numtimestables', '2004-07-16', 'Friday', '07:20:51', NULL, 15, 6, NULL, 2);
INSERT INTO `PTHomeWork1` VALUES (249, 10, 'numtimestables', '2004-07-16', 'Friday', '08:55:28', NULL, 15, 2, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (250, 10, 'numtimestables', '2004-07-18', 'Sunday', '07:26:17', NULL, 15, 7, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (251, 10, 'numtimestables', '2004-07-22', 'Thursday', '07:18:50', NULL, 15, 4, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (252, 10, 'numtimestables', '2004-07-23', 'Friday', '09:24:28', NULL, 15, 3, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (253, 10, 'numtimestables', '2004-07-26', 'Monday', '06:55:32', NULL, 15, 7, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (254, 10, 'numtimestables', '2004-07-30', 'Friday', '11:09:26', NULL, 15, 4, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (255, 10, 'numtimestables', '2004-08-03', 'Tuesday', '18:37:41', NULL, 15, 3, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (256, 10, 'numtimestables', '2004-08-06', 'Friday', '11:55:08', NULL, 15, 5, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (257, 10, 'numtimestables', '2004-08-07', 'Saturday', '00:18:16', NULL, 15, 9, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (258, 10, 'numtimestables', '2004-08-08', 'Sunday', '17:07:13', NULL, 15, 3, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (259, 10, 'numtimestables', '2004-08-09', 'Monday', '00:46:19', NULL, 15, 8, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (260, 10, 'numtimestables', '2004-08-09', 'Monday', '10:43:44', NULL, 15, 2, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (261, 10, 'numtimestables', '2004-08-10', 'Tuesday', '22:19:02', NULL, 15, 4, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (262, 10, 'numtimestables', '2004-08-13', 'Friday', '14:07:49', NULL, 15, 5, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (263, 10, 'numtimestables', '2004-08-15', 'Sunday', '06:39:11', NULL, 15, 8, NULL, 3);
INSERT INTO `PTHomeWork1` VALUES (264, 10, 'numtimestables', '2004-08-15', 'Sunday', '07:17:22', NULL, 15, 8, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (265, 10, 'numtimestables', '2004-08-18', 'Wednesday', '09:11:13', NULL, 15, 5, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (266, 10, 'numtimestables', '2004-08-21', 'Saturday', '10:15:29', NULL, 15, 4, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (267, 10, 'numtimestables', '2004-08-22', 'Sunday', '23:16:30', NULL, 15, 9, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (268, 10, 'numtimestables', '2004-08-24', 'Tuesday', '12:26:38', NULL, 15, 2, NULL, 2);
INSERT INTO `PTHomeWork1` VALUES (269, 10, 'numtimestables', '2004-08-24', 'Tuesday', '16:30:51', NULL, 15, 4, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (270, 10, 'numtimestables', '2004-08-24', 'Tuesday', '18:59:45', NULL, 15, 8, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (271, 10, 'numtimestables', '2004-08-25', 'Wednesday', '17:24:17', NULL, 15, 7, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (272, 10, 'numtimestables', '2004-08-26', 'Thursday', '20:03:05', NULL, 15, 3, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (273, 10, 'numtimestables', '2004-08-27', 'Friday', '14:51:00', NULL, 15, 5, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (274, 10, 'numtimestables', '2004-08-27', 'Friday', '18:44:38', NULL, 15, 8, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (275, 10, 'numtimestables', '2004-08-30', 'Monday', '07:51:53', NULL, 15, 7, NULL, 28);
INSERT INTO `PTHomeWork1` VALUES (276, 10, 'numtimestables', '2004-08-30', 'Monday', '16:48:27', NULL, 15, 7, NULL, 2);
INSERT INTO `PTHomeWork1` VALUES (277, 10, 'numtimestables', '2004-09-02', 'Thursday', '20:49:01', NULL, 15, 4, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (278, 10, 'numtimestables', '2004-09-08', 'Wednesday', '14:51:14', NULL, 15, 4, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (279, 10, 'numtimestables', '2004-09-09', 'Thursday', '01:50:25', NULL, 15, 9, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (280, 10, 'numtimestables', '2004-09-12', 'Sunday', '03:37:38', NULL, 15, 6, NULL, 4);
INSERT INTO `PTHomeWork1` VALUES (281, 10, 'numtimestables', '2004-09-14', 'Tuesday', '07:52:01', NULL, 15, 5, NULL, 3);
INSERT INTO `PTHomeWork1` VALUES (282, 10, 'numtimestables', '2004-09-15', 'Wednesday', '05:13:20', NULL, 15, 3, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (283, 10, 'numtimestables', '2004-09-19', 'Sunday', '02:07:02', NULL, 15, 7, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (284, 10, 'numtimestables', '2004-09-19', 'Sunday', '20:32:37', NULL, 15, 4, NULL, 4);
INSERT INTO `PTHomeWork1` VALUES (285, 10, 'numtimestables', '2004-09-23', 'Thursday', '00:28:18', NULL, 15, 8, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (286, 10, 'numtimestables', '2004-09-23', 'Thursday', '06:20:29', NULL, 15, 4, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (287, 10, 'numtimestables', '2004-09-24', 'Friday', '13:42:06', NULL, 15, 9, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (288, 10, 'numtimestables', '2004-09-27', 'Monday', '21:32:31', NULL, 15, 6, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (289, 10, 'numtimestables', '2004-09-28', 'Tuesday', '04:17:51', NULL, 15, 3, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (290, 10, 'numtimestables', '2004-09-29', 'Wednesday', '07:51:37', NULL, 15, 7, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (291, 10, 'numtimestables', '2004-09-29', 'Wednesday', '21:34:06', NULL, 15, 9, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (292, 10, 'numtimestables', '2004-09-29', 'Wednesday', '21:34:06', NULL, 15, 3, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (293, 10, 'numtimestables', '2004-10-03', 'Sunday', '15:19:39', NULL, 15, 6, NULL, 7);
INSERT INTO `PTHomeWork1` VALUES (294, 10, 'numtimestables', '2004-10-05', 'Tuesday', '14:55:34', NULL, 15, 6, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (295, 10, 'numtimestables', '2004-10-08', 'Friday', '23:50:48', NULL, 15, 4, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (296, 10, 'numtimestables', '2004-10-08', 'Friday', '23:50:48', NULL, 15, 8, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (297, 10, 'numtimestables', '2004-10-10', 'Sunday', '17:12:27', NULL, 15, 2, NULL, 7);
INSERT INTO `PTHomeWork1` VALUES (298, 10, 'numtimestables', '2004-10-11', 'Monday', '12:08:40', NULL, 15, 4, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (299, 10, 'numtimestables', '2004-10-14', 'Thursday', '02:38:55', NULL, 15, 4, NULL, 2);
INSERT INTO `PTHomeWork1` VALUES (300, 10, 'numtimestables', '2004-10-14', 'Thursday', '08:00:56', NULL, 15, 5, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (301, 10, 'numtimestables', '2004-10-14', 'Thursday', '11:43:23', NULL, 15, 8, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (302, 10, 'numtimestables', '2004-10-18', 'Monday', '20:32:44', NULL, 15, 6, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (303, 10, 'numtimestables', '2004-10-18', 'Monday', '22:51:53', NULL, 15, 8, NULL, 5);
INSERT INTO `PTHomeWork1` VALUES (304, 10, 'numtimestables', '2004-10-19', 'Tuesday', '10:39:49', NULL, 15, 6, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (305, 10, 'numtimestables', '2004-10-19', 'Tuesday', '10:40:00', NULL, 15, 3, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (306, 10, 'numtimestables', '2004-10-19', 'Tuesday', '13:40:41', NULL, 15, 3, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (307, 10, 'numtimestables', '2004-10-20', 'Wednesday', '17:06:58', NULL, 15, 5, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (308, 10, 'numtimestables', '2004-10-22', 'Friday', '01:59:00', NULL, 15, 6, NULL, 6);
INSERT INTO `PTHomeWork1` VALUES (309, 10, 'numtimestables', '2004-10-22', 'Friday', '03:37:31', NULL, 15, 5, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (310, 10, 'numtimestables', '2004-10-23', 'Saturday', '05:55:37', NULL, 15, 6, NULL, 4);
INSERT INTO `PTHomeWork1` VALUES (311, 10, 'numtimestables', '2004-10-24', 'Sunday', '08:38:33', NULL, 15, 2, NULL, 6);
INSERT INTO `PTHomeWork1` VALUES (312, 10, 'numtimestables', '2004-10-25', 'Monday', '13:05:33', NULL, 15, 5, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (313, 10, 'numtimestables', '2004-10-25', 'Monday', '22:47:52', NULL, 15, 8, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (314, 10, 'numtimestables', '2004-10-26', 'Tuesday', '18:48:29', NULL, 15, 6, NULL, 4);
INSERT INTO `PTHomeWork1` VALUES (315, 10, 'numtimestables', '2004-10-28', 'Thursday', '05:54:09', NULL, 15, 6, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (316, 10, 'numtimestables', '2004-10-29', 'Friday', '08:01:34', NULL, 15, 2, NULL, 28);
INSERT INTO `PTHomeWork1` VALUES (317, 10, 'numtimestables', '2004-11-06', 'Saturday', '12:20:44', NULL, 15, 6, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (318, 10, 'numtimestables', '2004-11-10', 'Wednesday', '13:28:00', NULL, 15, 7, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (319, 10, 'numtimestables', '2004-11-11', 'Thursday', '01:29:59', NULL, 15, 7, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (320, 10, 'numtimestables', '2004-11-12', 'Friday', '01:14:18', NULL, 15, 6, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (321, 10, 'numtimestables', '2004-11-12', 'Friday', '09:14:03', NULL, 15, 7, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (322, 10, 'numtimestables', '2004-11-13', 'Saturday', '09:58:49', NULL, 15, 6, NULL, 2);
INSERT INTO `PTHomeWork1` VALUES (323, 10, 'numtimestables', '2004-11-14', 'Sunday', '01:20:33', NULL, 15, 7, NULL, 28);
INSERT INTO `PTHomeWork1` VALUES (324, 10, 'numtimestables', '2004-11-22', 'Monday', '02:14:11', NULL, 15, 2, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (325, 10, 'numtimestables', '2004-11-22', 'Monday', '08:52:58', NULL, 15, 2, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (326, 10, 'numtimestables', '2004-11-23', 'Tuesday', '22:27:51', NULL, 15, 3, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (327, 10, 'numtimestables', '2004-11-27', 'Saturday', '11:05:00', NULL, 15, 3, NULL, 7);
INSERT INTO `PTHomeWork1` VALUES (328, 10, 'numtimestables', '2004-11-28', 'Sunday', '03:40:28', NULL, 15, 4, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (329, 10, 'numtimestables', '2004-12-04', 'Saturday', '02:42:12', NULL, 15, 5, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (330, 10, 'numtimestables', '2004-12-04', 'Saturday', '17:53:54', NULL, 15, 8, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (331, 10, 'numtimestables', '2004-12-05', 'Sunday', '05:35:49', NULL, 15, 5, NULL, 27);
INSERT INTO `PTHomeWork1` VALUES (332, 10, 'numtimestables', '2004-12-06', 'Monday', '19:45:50', NULL, 15, 8, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (333, 10, 'numtimestables', '2004-12-07', 'Tuesday', '12:13:03', NULL, 15, 3, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (334, 10, 'numtimestables', '2004-12-07', 'Tuesday', '12:13:06', NULL, 15, 9, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (335, 10, 'numtimestables', '2004-12-07', 'Tuesday', '12:13:31', NULL, 15, 7, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (336, 10, 'numtimestables', '2004-12-07', 'Tuesday', '12:13:33', NULL, 15, 7, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (337, 10, 'numtimestables', '2004-12-08', 'Wednesday', '21:38:41', NULL, 15, 5, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (338, 10, 'numtimestables', '2004-12-10', 'Friday', '15:32:02', NULL, 15, 2, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (339, 10, 'numtimestables', '2004-12-10', 'Friday', '16:09:53', NULL, 15, 7, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (340, 10, 'numtimestables', '2004-12-10', 'Friday', '20:19:16', NULL, 15, 5, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (341, 10, 'numtimestables', '2004-12-11', 'Saturday', '08:29:35', NULL, 15, 7, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (342, 10, 'numtimestables', '2004-12-14', 'Tuesday', '13:12:30', NULL, 15, 9, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (343, 10, 'numtimestables', '2004-12-14', 'Tuesday', '13:24:34', NULL, 15, 2, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (344, 10, 'numtimestables', '2004-12-14', 'Tuesday', '23:08:13', NULL, 15, 3, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (345, 10, 'numtimestables', '2004-12-19', 'Sunday', '11:25:14', NULL, 15, 3, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (346, 10, 'numtimestables', '2004-12-19', 'Sunday', '13:36:11', NULL, 15, 5, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (347, 10, 'numtimestables', '2004-12-20', 'Monday', '09:58:18', NULL, 15, 9, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (348, 10, 'numtimestables', '2004-12-21', 'Tuesday', '04:19:28', NULL, 15, 4, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (349, 10, 'numtimestables', '2004-12-21', 'Tuesday', '12:58:53', NULL, 15, 7, NULL, 26);
INSERT INTO `PTHomeWork1` VALUES (350, 10, 'numtimestables', '2004-12-22', 'Wednesday', '11:40:53', NULL, 15, 7, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (351, 10, 'numtimestables', '2004-12-22', 'Wednesday', '11:40:55', NULL, 15, 6, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (352, 10, 'numtimestables', '2004-12-22', 'Wednesday', '11:41:12', NULL, 15, 4, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (353, 10, 'numtimestables', '2004-12-22', 'Wednesday', '11:41:15', NULL, 15, 2, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (354, 10, 'numtimestables', '2004-12-22', 'Wednesday', '13:17:24', NULL, 15, 4, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (355, 10, 'numtimestables', '2004-12-23', 'Thursday', '17:32:57', NULL, 15, 5, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (356, 10, 'numtimestables', '2004-12-25', 'Saturday', '18:22:20', NULL, 15, 3, NULL, 4);
INSERT INTO `PTHomeWork1` VALUES (357, 10, 'numtimestables', '2004-12-27', 'Monday', '00:06:30', NULL, 15, 4, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (358, 10, 'numtimestables', '2004-12-31', 'Friday', '20:23:25', NULL, 15, 3, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (359, 10, 'numtimestables', '2005-01-02', 'Sunday', '17:52:27', NULL, 15, 6, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (360, 10, 'numtimestables', '2005-01-06', 'Thursday', '01:19:39', NULL, 15, 8, NULL, 3);
INSERT INTO `PTHomeWork1` VALUES (361, 10, 'numtimestables', '2005-01-06', 'Thursday', '21:21:04', NULL, 15, 5, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (362, 10, 'numtimestables', '2005-01-11', 'Tuesday', '17:00:25', NULL, 15, 3, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (363, 10, 'numtimestables', '2005-01-11', 'Tuesday', '17:03:12', NULL, 15, 2, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (364, 10, 'numtimestables', '2005-01-13', 'Thursday', '02:11:42', NULL, 15, 9, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (365, 10, 'numtimestables', '2005-01-15', 'Saturday', '07:22:11', NULL, 15, 9, NULL, 3);
INSERT INTO `PTHomeWork1` VALUES (366, 10, 'numtimestables', '2005-01-19', 'Wednesday', '09:07:08', NULL, 15, 2, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (367, 10, 'numtimestables', '2005-01-21', 'Friday', '11:01:09', NULL, 15, 4, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (368, 10, 'numtimestables', '2005-01-21', 'Friday', '15:12:28', NULL, 15, 9, NULL, 3);
INSERT INTO `PTHomeWork1` VALUES (369, 10, 'numtimestables', '2005-01-21', 'Friday', '16:13:01', NULL, 15, 2, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (370, 10, 'numtimestables', '2005-01-22', 'Saturday', '20:04:14', NULL, 15, 7, NULL, 2);
INSERT INTO `PTHomeWork1` VALUES (371, 10, 'numtimestables', '2005-01-22', 'Saturday', '23:20:39', NULL, 15, 6, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (372, 10, 'numtimestables', '2005-01-22', 'Saturday', '23:20:41', NULL, 15, 8, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (373, 10, 'numtimestables', '2005-01-22', 'Saturday', '23:38:36', NULL, 15, 7, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (374, 10, 'numtimestables', '2005-01-24', 'Monday', '14:35:21', NULL, 15, 5, NULL, 2);
INSERT INTO `PTHomeWork1` VALUES (375, 10, 'numtimestables', '2005-01-25', 'Tuesday', '14:52:58', NULL, 15, 5, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (376, 10, 'numtimestables', '2005-01-26', 'Wednesday', '15:53:01', NULL, 15, 8, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (377, 10, 'numtimestables', '2005-01-27', 'Thursday', '16:36:51', NULL, 15, 4, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (378, 10, 'numtimestables', '2005-01-27', 'Thursday', '17:47:28', NULL, 15, 3, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (379, 10, 'numtimestables', '2005-01-27', 'Thursday', '17:48:28', NULL, 15, 9, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (380, 10, 'numtimestables', '2005-01-27', 'Thursday', '17:48:58', NULL, 15, 8, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (381, 10, 'numtimestables', '2005-01-28', 'Friday', '17:58:44', NULL, 15, 5, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (382, 10, 'numtimestables', '2005-01-29', 'Saturday', '18:41:26', NULL, 15, 2, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (383, 10, 'numtimestables', '2005-01-30', 'Sunday', '15:46:57', NULL, 15, 4, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (384, 10, 'numtimestables', '2005-01-30', 'Sunday', '20:17:25', NULL, 15, 7, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (385, 10, 'numtimestables', '2005-01-31', 'Monday', '13:56:01', NULL, 15, 8, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (386, 10, 'numtimestables', '2005-01-31', 'Monday', '22:03:08', NULL, 15, 6, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (387, 10, 'numtimestables', '2005-02-01', 'Tuesday', '09:16:33', NULL, 15, 3, NULL, 7);
INSERT INTO `PTHomeWork1` VALUES (388, 10, 'numtimestables', '2005-02-01', 'Tuesday', '21:09:53', NULL, 15, 5, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (389, 10, 'numtimestables', '2005-02-01', 'Tuesday', '22:45:52', NULL, 15, 4, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (390, 10, 'numtimestables', '2005-02-03', 'Thursday', '12:44:36', NULL, 15, 3, NULL, 5);
INSERT INTO `PTHomeWork1` VALUES (391, 10, 'numtimestables', '2005-02-04', 'Friday', '17:41:53', NULL, 15, 5, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (392, 10, 'numtimestables', '2005-02-05', 'Saturday', '16:32:57', NULL, 15, 8, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (393, 10, 'numtimestables', '2005-02-05', 'Saturday', '19:09:24', NULL, 15, 2, NULL, 2);
INSERT INTO `PTHomeWork1` VALUES (394, 10, 'numtimestables', '2005-02-05', 'Saturday', '20:46:12', NULL, 15, 3, NULL, 3);
INSERT INTO `PTHomeWork1` VALUES (395, 10, 'numtimestables', '2005-02-06', 'Sunday', '20:05:01', NULL, 15, 5, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (396, 10, 'numtimestables', '2005-02-07', 'Monday', '11:58:31', NULL, 15, 8, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (397, 10, 'numtimestables', '2005-02-07', 'Monday', '12:20:05', NULL, 15, 2, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (398, 10, 'numtimestables', '2005-02-07', 'Monday', '22:03:14', NULL, 15, 5, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (399, 10, 'numtimestables', '2005-02-08', 'Tuesday', '21:16:33', NULL, 15, 9, NULL, 8);
INSERT INTO `PTHomeWork1` VALUES (400, 10, 'numtimestables', '2005-02-08', 'Tuesday', '23:22:28', NULL, 15, 9, NULL, 2);
INSERT INTO `PTHomeWork1` VALUES (401, 10, 'numtimestables', '2005-02-09', 'Wednesday', '11:20:14', NULL, 15, 5, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (402, 10, 'numtimestables', '2005-02-10', 'Thursday', '00:52:14', NULL, 15, 5, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (403, 10, 'numtimestables', '2005-02-10', 'Thursday', '16:45:37', NULL, 15, 4, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (404, 10, 'numtimestables', '2005-02-11', 'Friday', '02:51:38', NULL, 15, 4, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (405, 10, 'numtimestables', '2005-02-12', 'Saturday', '03:23:02', NULL, 15, 7, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (406, 10, 'numtimestables', '2005-02-12', 'Saturday', '14:52:10', NULL, 15, 4, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (407, 10, 'numtimestables', '2005-02-13', 'Sunday', '05:30:42', NULL, 15, 8, NULL, 5);
INSERT INTO `PTHomeWork1` VALUES (408, 10, 'numtimestables', '2005-02-14', 'Monday', '05:58:53', NULL, 15, 9, NULL, 5);
INSERT INTO `PTHomeWork1` VALUES (409, 10, 'numtimestables', '2005-02-15', 'Tuesday', '06:40:06', NULL, 15, 5, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (410, 10, 'numtimestables', '2005-02-16', 'Wednesday', '07:34:26', NULL, 15, 8, NULL, 2);
INSERT INTO `PTHomeWork1` VALUES (411, 10, 'numtimestables', '2005-02-16', 'Wednesday', '08:56:57', NULL, 15, 4, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (412, 10, 'numtimestables', '2005-02-16', 'Wednesday', '08:59:08', NULL, 15, 2, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (413, 10, 'numtimestables', '2005-02-17', 'Thursday', '14:49:27', NULL, 15, 7, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (414, 10, 'numtimestables', '2005-02-17', 'Thursday', '16:42:21', NULL, 15, 5, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (415, 10, 'numtimestables', '2005-02-17', 'Thursday', '20:19:45', NULL, 15, 8, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (416, 10, 'numtimestables', '2005-02-18', 'Friday', '15:43:30', NULL, 15, 6, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (417, 10, 'numtimestables', '2005-02-18', 'Friday', '21:08:25', NULL, 15, 8, NULL, 7);
INSERT INTO `PTHomeWork1` VALUES (418, 10, 'numtimestables', '2005-02-19', 'Saturday', '21:30:33', NULL, 15, 5, NULL, 2);
INSERT INTO `PTHomeWork1` VALUES (419, 10, 'numtimestables', '2005-02-21', 'Monday', '07:54:10', NULL, 15, 7, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (420, 10, 'numtimestables', '2005-02-22', 'Tuesday', '21:55:48', NULL, 15, 8, NULL, 2);
INSERT INTO `PTHomeWork1` VALUES (421, 10, 'numtimestables', '2005-02-24', 'Thursday', '23:55:46', NULL, 15, 3, NULL, 2);
INSERT INTO `PTHomeWork1` VALUES (422, 10, 'numtimestables', '2005-02-26', 'Saturday', '01:45:13', NULL, 15, 9, NULL, 4);
INSERT INTO `PTHomeWork1` VALUES (423, 10, 'numtimestables', '2005-02-26', 'Saturday', '13:04:47', NULL, 15, 4, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (424, 10, 'numtimestables', '2005-02-27', 'Sunday', '06:46:02', NULL, 15, 5, NULL, 3);
INSERT INTO `PTHomeWork1` VALUES (425, 10, 'numtimestables', '2005-02-27', 'Sunday', '07:42:54', NULL, 15, 6, NULL, 6);
INSERT INTO `PTHomeWork1` VALUES (426, 10, 'numtimestables', '2005-02-28', 'Monday', '08:26:22', NULL, 15, 6, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (427, 10, 'numtimestables', '2005-02-28', 'Monday', '14:44:10', NULL, 15, 2, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (428, 10, 'numtimestables', '2005-02-28', 'Monday', '14:44:21', NULL, 15, 6, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (429, 10, 'numtimestables', '2005-03-01', 'Tuesday', '12:08:52', NULL, 15, 4, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (430, 10, 'numtimestables', '2005-03-03', 'Thursday', '07:15:26', NULL, 15, 3, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (431, 10, 'numtimestables', '2005-03-03', 'Thursday', '21:55:11', NULL, 15, 3, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (432, 10, 'numtimestables', '2005-03-04', 'Friday', '22:23:27', NULL, 15, 6, NULL, 14);
INSERT INTO `PTHomeWork1` VALUES (433, 10, 'numtimestables', '2005-03-05', 'Saturday', '01:46:55', NULL, 15, 4, NULL, 3);
INSERT INTO `PTHomeWork1` VALUES (434, 10, 'numtimestables', '2005-03-06', 'Sunday', '09:36:59', NULL, 15, 4, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (435, 10, 'numtimestables', '2005-03-07', 'Monday', '12:41:04', NULL, 15, 7, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (436, 10, 'numtimestables', '2005-03-08', 'Tuesday', '13:52:42', NULL, 15, 5, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (437, 10, 'numtimestables', '2005-03-08', 'Tuesday', '16:23:30', NULL, 15, 5, NULL, 14);
INSERT INTO `PTHomeWork1` VALUES (438, 10, 'numtimestables', '2005-03-09', 'Wednesday', '15:05:31', NULL, 15, 2, NULL, 2);
INSERT INTO `PTHomeWork1` VALUES (439, 10, 'numtimestables', '2005-03-10', 'Thursday', '03:18:13', NULL, 15, 2, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (440, 10, 'numtimestables', '2005-03-10', 'Thursday', '16:44:12', NULL, 15, 8, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (441, 10, 'numtimestables', '2005-03-11', 'Friday', '18:18:29', NULL, 15, 9, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (442, 10, 'numtimestables', '2005-03-12', 'Saturday', '00:02:41', NULL, 15, 4, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (443, 10, 'numtimestables', '2005-03-12', 'Saturday', '10:23:34', NULL, 15, 6, NULL, 8);
INSERT INTO `PTHomeWork1` VALUES (444, 10, 'numtimestables', '2005-03-12', 'Saturday', '19:43:04', NULL, 15, 6, NULL, 4);
INSERT INTO `PTHomeWork1` VALUES (445, 10, 'numtimestables', '2005-03-13', 'Sunday', '18:40:49', NULL, 15, 7, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (446, 10, 'numtimestables', '2005-03-13', 'Sunday', '20:18:34', NULL, 15, 7, NULL, 2);
INSERT INTO `PTHomeWork1` VALUES (447, 10, 'numtimestables', '2005-03-14', 'Monday', '03:07:16', NULL, 15, 5, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (448, 10, 'numtimestables', '2005-03-15', 'Tuesday', '04:28:34', NULL, 15, 3, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (449, 10, 'numtimestables', '2005-03-16', 'Wednesday', '04:23:32', NULL, 15, 3, NULL, 11);
INSERT INTO `PTHomeWork1` VALUES (450, 10, 'numtimestables', '2005-03-16', 'Wednesday', '06:07:42', NULL, 15, 7, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (451, 10, 'numtimestables', '2005-03-17', 'Thursday', '07:28:20', NULL, 15, 7, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (452, 10, 'numtimestables', '2005-03-18', 'Friday', '08:08:53', NULL, 15, 9, NULL, 3);
INSERT INTO `PTHomeWork1` VALUES (453, 10, 'numtimestables', '2005-03-18', 'Friday', '21:46:22', NULL, 15, 7, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (454, 10, 'numtimestables', '2005-03-19', 'Saturday', '21:27:15', NULL, 15, 8, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (455, 10, 'numtimestables', '2005-03-19', 'Saturday', '22:23:34', NULL, 15, 4, NULL, 8);
INSERT INTO `PTHomeWork1` VALUES (456, 10, 'numtimestables', '2005-03-20', 'Sunday', '02:44:53', NULL, 15, 6, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (457, 10, 'numtimestables', '2005-03-21', 'Monday', '10:53:44', NULL, 15, 2, NULL, 3);
INSERT INTO `PTHomeWork1` VALUES (458, 10, 'numtimestables', '2005-03-21', 'Monday', '21:39:52', NULL, 15, 6, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (459, 10, 'numtimestables', '2005-03-22', 'Tuesday', '11:51:32', NULL, 15, 3, NULL, 2);
INSERT INTO `PTHomeWork1` VALUES (460, 10, 'numtimestables', '2005-03-23', 'Wednesday', '12:58:02', NULL, 15, 8, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (461, 10, 'numtimestables', '2005-03-23', 'Wednesday', '16:23:37', NULL, 15, 7, NULL, 11);
INSERT INTO `PTHomeWork1` VALUES (462, 10, 'numtimestables', '2005-03-24', 'Thursday', '14:21:04', NULL, 15, 4, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (463, 10, 'numtimestables', '2005-03-25', 'Friday', '15:43:58', NULL, 15, 8, NULL, 2);
INSERT INTO `PTHomeWork1` VALUES (464, 10, 'numtimestables', '2005-03-26', 'Saturday', '16:48:40', NULL, 15, 3, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (465, 10, 'numtimestables', '2005-03-27', 'Sunday', '10:23:39', NULL, 15, 9, NULL, 11);
INSERT INTO `PTHomeWork1` VALUES (466, 10, 'numtimestables', '2005-03-27', 'Sunday', '14:26:42', NULL, 15, 5, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (467, 10, 'numtimestables', '2005-03-27', 'Sunday', '19:29:42', NULL, 15, 6, NULL, 2);
INSERT INTO `PTHomeWork1` VALUES (468, 10, 'numtimestables', '2005-03-28', 'Monday', '20:50:38', NULL, 15, 6, NULL, 2);
INSERT INTO `PTHomeWork1` VALUES (469, 10, 'numtimestables', '2005-03-29', 'Tuesday', '05:55:27', NULL, 15, 7, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (470, 10, 'numtimestables', '2005-03-29', 'Tuesday', '21:28:36', NULL, 15, 6, NULL, 3);
INSERT INTO `PTHomeWork1` VALUES (471, 10, 'numtimestables', '2005-03-31', 'Thursday', '04:23:37', NULL, 15, 5, NULL, 14);
INSERT INTO `PTHomeWork1` VALUES (472, 10, 'numtimestables', '2005-03-31', 'Thursday', '18:01:13', NULL, 15, 5, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (473, 10, 'numtimestables', '2005-04-01', 'Friday', '18:36:17', NULL, 15, 3, NULL, 2);
INSERT INTO `PTHomeWork1` VALUES (474, 10, 'numtimestables', '2005-04-02', 'Saturday', '20:21:42', NULL, 15, 9, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (475, 10, 'numtimestables', '2005-04-03', 'Sunday', '23:23:37', NULL, 15, 7, NULL, 12);
INSERT INTO `PTHomeWork1` VALUES (476, 10, 'numtimestables', '2005-04-04', 'Monday', '12:37:23', NULL, 15, 6, NULL, 2);
INSERT INTO `PTHomeWork1` VALUES (477, 10, 'numtimestables', '2005-04-04', 'Monday', '13:16:26', NULL, 15, 4, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (478, 10, 'numtimestables', '2005-04-05', 'Tuesday', '17:32:45', NULL, 15, 3, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (479, 10, 'numtimestables', '2005-04-05', 'Tuesday', '18:50:35', NULL, 15, 9, NULL, 2);
INSERT INTO `PTHomeWork1` VALUES (480, 10, 'numtimestables', '2005-04-07', 'Thursday', '01:38:31', NULL, 15, 2, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (481, 10, 'numtimestables', '2005-04-07', 'Thursday', '19:06:54', NULL, 15, 4, NULL, 10);
INSERT INTO `PTHomeWork1` VALUES (482, 10, 'numtimestables', '2005-04-07', 'Thursday', '19:16:14', NULL, 15, 3, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (483, 10, 'numtimestables', '2005-04-08', 'Friday', '14:21:20', NULL, 15, 4, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (484, 10, 'numtimestables', '2005-04-11', 'Monday', '13:06:58', NULL, 15, 8, NULL, 10);
INSERT INTO `PTHomeWork1` VALUES (485, 10, 'numtimestables', '2005-04-14', 'Thursday', '08:35:09', NULL, 15, 8, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (486, 10, 'numtimestables', '2005-04-15', 'Friday', '07:07:01', NULL, 15, 6, NULL, 9);
INSERT INTO `PTHomeWork1` VALUES (487, 10, 'numtimestables', '2005-04-15', 'Friday', '10:53:12', NULL, 15, 9, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (488, 10, 'numtimestables', '2005-04-15', 'Friday', '17:46:46', NULL, 15, 6, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (489, 10, 'numtimestables', '2005-04-17', 'Sunday', '02:23:27', NULL, 15, 9, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (490, 10, 'numtimestables', '2005-04-18', 'Monday', '12:57:09', NULL, 15, 4, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (491, 10, 'numtimestables', '2005-04-19', 'Tuesday', '01:07:00', NULL, 15, 5, NULL, 9);
INSERT INTO `PTHomeWork1` VALUES (492, 10, 'numtimestables', '2005-04-22', 'Friday', '19:07:02', NULL, 15, 9, NULL, 11);
INSERT INTO `PTHomeWork1` VALUES (493, 10, 'numtimestables', '2005-04-23', 'Saturday', '12:03:27', NULL, 15, 3, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (494, 10, 'numtimestables', '2005-04-23', 'Saturday', '12:32:11', NULL, 15, 4, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (495, 10, 'numtimestables', '2005-04-23', 'Saturday', '12:38:48', NULL, 15, 7, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (496, 10, 'numtimestables', '2005-04-23', 'Saturday', '16:39:46', NULL, 15, 8, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (497, 10, 'numtimestables', '2005-04-23', 'Saturday', '16:49:11', NULL, 15, 3, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (498, 10, 'numtimestables', '2005-04-25', 'Monday', '05:13:50', NULL, 15, 4, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (499, 10, 'numtimestables', '2005-04-26', 'Tuesday', '05:29:56', NULL, 15, 5, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (500, 10, 'numtimestables', '2005-04-26', 'Tuesday', '13:07:04', NULL, 15, 8, NULL, 10);
INSERT INTO `PTHomeWork1` VALUES (501, 10, 'numtimestables', '2005-04-27', 'Wednesday', '10:34:59', NULL, 15, 2, NULL, 2);
INSERT INTO `PTHomeWork1` VALUES (502, 10, 'numtimestables', '2005-04-27', 'Wednesday', '21:43:19', NULL, 15, 2, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (503, 10, 'numtimestables', '2005-04-28', 'Thursday', '01:28:18', NULL, 15, 7, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (504, 10, 'numtimestables', '2005-04-28', 'Thursday', '10:59:58', NULL, 15, 8, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (505, 10, 'numtimestables', '2005-04-28', 'Thursday', '21:43:24', NULL, 15, 8, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (506, 10, 'numtimestables', '2005-04-29', 'Friday', '03:50:01', NULL, 15, 7, NULL, 9);
INSERT INTO `PTHomeWork1` VALUES (507, 10, 'numtimestables', '2005-04-29', 'Friday', '12:06:26', NULL, 15, 2, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (508, 10, 'numtimestables', '2005-04-30', 'Saturday', '12:59:13', NULL, 15, 3, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (509, 10, 'numtimestables', '2005-05-01', 'Sunday', '05:15:21', NULL, 15, 5, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (510, 10, 'numtimestables', '2005-05-01', 'Sunday', '13:40:42', NULL, 15, 7, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (511, 10, 'numtimestables', '2005-05-02', 'Monday', '09:05:51', NULL, 15, 9, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (512, 10, 'numtimestables', '2005-05-02', 'Monday', '14:42:15', NULL, 15, 6, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (513, 10, 'numtimestables', '2005-05-03', 'Tuesday', '09:24:54', NULL, 15, 5, NULL, 8);
INSERT INTO `PTHomeWork1` VALUES (514, 10, 'numtimestables', '2005-05-03', 'Tuesday', '15:38:49', NULL, 15, 3, NULL, 2);
INSERT INTO `PTHomeWork1` VALUES (515, 10, 'numtimestables', '2005-05-04', 'Wednesday', '18:27:45', NULL, 15, 5, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (516, 10, 'numtimestables', '2005-05-05', 'Thursday', '20:00:18', NULL, 15, 8, NULL, 3);
INSERT INTO `PTHomeWork1` VALUES (517, 10, 'numtimestables', '2005-05-06', 'Friday', '21:15:27', NULL, 15, 9, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (518, 10, 'numtimestables', '2005-05-07', 'Saturday', '06:06:22', NULL, 15, 9, NULL, 12);
INSERT INTO `PTHomeWork1` VALUES (519, 10, 'numtimestables', '2005-05-07', 'Saturday', '22:33:15', NULL, 15, 5, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (520, 10, 'numtimestables', '2005-05-08', 'Sunday', '15:58:51', NULL, 15, 2, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (521, 10, 'numtimestables', '2005-05-09', 'Monday', '00:28:06', NULL, 15, 8, NULL, 4);
INSERT INTO `PTHomeWork1` VALUES (522, 10, 'numtimestables', '2005-05-10', 'Tuesday', '04:47:54', NULL, 15, 8, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (523, 10, 'numtimestables', '2005-05-11', 'Wednesday', '00:06:27', NULL, 15, 6, NULL, 10);
INSERT INTO `PTHomeWork1` VALUES (524, 10, 'numtimestables', '2005-05-11', 'Wednesday', '05:41:39', NULL, 15, 9, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (525, 10, 'numtimestables', '2005-05-12', 'Thursday', '05:43:04', NULL, 15, 4, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (526, 10, 'numtimestables', '2005-05-13', 'Friday', '06:24:55', NULL, 15, 4, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (527, 10, 'numtimestables', '2005-05-14', 'Saturday', '08:00:54', NULL, 15, 9, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (528, 10, 'numtimestables', '2005-05-14', 'Saturday', '08:07:57', NULL, 15, 6, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (529, 10, 'numtimestables', '2005-05-14', 'Saturday', '18:06:30', NULL, 15, 8, NULL, 3);
INSERT INTO `PTHomeWork1` VALUES (530, 10, 'numtimestables', '2005-05-15', 'Sunday', '07:49:30', NULL, 15, 8, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (531, 10, 'numtimestables', '2005-05-15', 'Sunday', '08:59:08', NULL, 15, 2, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (532, 10, 'numtimestables', '2005-05-15', 'Sunday', '13:27:19', NULL, 15, 7, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (533, 10, 'numtimestables', '2005-05-16', 'Monday', '13:44:45', NULL, 15, 4, NULL, 3);
INSERT INTO `PTHomeWork1` VALUES (534, 10, 'numtimestables', '2005-05-17', 'Tuesday', '14:54:58', NULL, 15, 7, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (535, 10, 'numtimestables', '2005-05-18', 'Wednesday', '12:06:35', NULL, 15, 4, NULL, 6);
INSERT INTO `PTHomeWork1` VALUES (536, 10, 'numtimestables', '2005-05-18', 'Wednesday', '16:15:21', NULL, 15, 8, NULL, 2);
INSERT INTO `PTHomeWork1` VALUES (537, 10, 'numtimestables', '2005-05-19', 'Thursday', '17:02:34', NULL, 15, 7, NULL, 3);
INSERT INTO `PTHomeWork1` VALUES (538, 10, 'numtimestables', '2005-05-20', 'Friday', '19:00:22', NULL, 15, 5, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (539, 10, 'numtimestables', '2005-05-21', 'Saturday', '21:24:21', NULL, 15, 8, NULL, 2);
INSERT INTO `PTHomeWork1` VALUES (540, 10, 'numtimestables', '2005-05-22', 'Sunday', '06:06:38', NULL, 15, 2, NULL, 7);
INSERT INTO `PTHomeWork1` VALUES (541, 10, 'numtimestables', '2005-05-22', 'Sunday', '23:35:39', NULL, 15, 7, NULL, 2);
INSERT INTO `PTHomeWork1` VALUES (542, 10, 'numtimestables', '2005-05-24', 'Tuesday', '01:04:13', NULL, 15, 9, NULL, 2);
INSERT INTO `PTHomeWork1` VALUES (543, 10, 'numtimestables', '2005-05-24', 'Tuesday', '09:55:34', NULL, 15, 4, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (544, 10, 'numtimestables', '2005-05-24', 'Tuesday', '09:55:34', NULL, 15, 6, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (545, 10, 'numtimestables', '2005-05-25', 'Wednesday', '02:46:32', NULL, 15, 5, NULL, 2);
INSERT INTO `PTHomeWork1` VALUES (546, 10, 'numtimestables', '2005-05-26', 'Thursday', '00:06:38', NULL, 15, 3, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (547, 10, 'numtimestables', '2005-05-26', 'Thursday', '03:46:55', NULL, 15, 8, NULL, 2);
INSERT INTO `PTHomeWork1` VALUES (548, 10, 'numtimestables', '2005-05-26', 'Thursday', '04:02:04', NULL, 15, 8, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (549, 10, 'numtimestables', '2005-05-27', 'Friday', '05:46:33', NULL, 15, 7, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (550, 10, 'numtimestables', '2005-05-28', 'Saturday', '07:38:22', NULL, 15, 7, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (551, 10, 'numtimestables', '2005-05-29', 'Sunday', '08:31:35', NULL, 15, 8, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (552, 10, 'numtimestables', '2005-05-30', 'Monday', '09:05:05', NULL, 15, 5, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (553, 10, 'numtimestables', '2005-05-31', 'Tuesday', '10:30:16', NULL, 15, 5, NULL, 2);
INSERT INTO `PTHomeWork1` VALUES (554, 10, 'numtimestables', '2005-06-01', 'Wednesday', '11:37:58', NULL, 15, 8, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (555, 10, 'numtimestables', '2005-06-02', 'Thursday', '14:26:52', NULL, 15, 5, NULL, 2);
INSERT INTO `PTHomeWork1` VALUES (556, 10, 'numtimestables', '2005-06-03', 'Friday', '10:41:33', NULL, 15, 4, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (557, 10, 'numtimestables', '2005-06-03', 'Friday', '15:46:58', NULL, 15, 6, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (558, 10, 'numtimestables', '2005-06-04', 'Saturday', '16:30:30', NULL, 15, 9, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (559, 10, 'numtimestables', '2005-06-05', 'Sunday', '17:11:00', NULL, 15, 3, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (560, 10, 'numtimestables', '2005-06-05', 'Sunday', '18:41:39', NULL, 15, 2, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (561, 10, 'numtimestables', '2005-06-06', 'Monday', '18:01:50', NULL, 15, 8, NULL, 2);
INSERT INTO `PTHomeWork1` VALUES (562, 10, 'numtimestables', '2005-06-07', 'Tuesday', '19:28:40', NULL, 15, 2, NULL, 2);
INSERT INTO `PTHomeWork1` VALUES (563, 10, 'numtimestables', '2005-06-09', 'Thursday', '01:01:03', NULL, 15, 5, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (564, 10, 'numtimestables', '2005-06-09', 'Thursday', '16:54:57', NULL, 15, 2, NULL, 5);
INSERT INTO `PTHomeWork1` VALUES (565, 10, 'numtimestables', '2005-06-10', 'Friday', '09:08:36', NULL, 15, 7, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (566, 10, 'numtimestables', '2005-06-10', 'Friday', '09:09:16', NULL, 15, 3, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (567, 10, 'numtimestables', '2005-06-10', 'Friday', '17:44:54', NULL, 15, 7, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (568, 10, 'numtimestables', '2005-06-11', 'Saturday', '10:47:26', NULL, 15, 3, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (569, 10, 'numtimestables', '2005-06-11', 'Saturday', '11:35:08', NULL, 15, 3, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (570, 10, 'numtimestables', '2005-06-11', 'Saturday', '20:16:24', NULL, 15, 9, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (571, 10, 'numtimestables', '2005-06-12', 'Sunday', '16:07:26', NULL, 15, 6, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (572, 10, 'numtimestables', '2005-06-12', 'Sunday', '22:36:35', NULL, 15, 6, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (573, 10, 'numtimestables', '2005-06-12', 'Sunday', '23:37:05', NULL, 15, 2, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (574, 10, 'numtimestables', '2005-06-15', 'Wednesday', '19:47:40', NULL, 15, 6, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (575, 10, 'numtimestables', '2005-06-17', 'Friday', '11:06:08', NULL, 15, 3, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (576, 10, 'numtimestables', '2005-06-19', 'Sunday', '03:43:34', NULL, 15, 6, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (577, 10, 'numtimestables', '2005-06-19', 'Sunday', '03:43:36', NULL, 15, 3, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (578, 10, 'numtimestables', '2005-06-21', 'Tuesday', '09:35:57', NULL, 15, 6, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (579, 10, 'numtimestables', '2005-06-21', 'Tuesday', '11:02:06', NULL, 15, 9, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (580, 10, 'numtimestables', '2005-06-23', 'Thursday', '14:43:35', NULL, 15, 3, NULL, 3);
INSERT INTO `PTHomeWork1` VALUES (581, 10, 'numtimestables', '2005-06-24', 'Friday', '09:57:49', NULL, 15, 4, NULL, 4);
INSERT INTO `PTHomeWork1` VALUES (582, 10, 'numtimestables', '2005-06-25', 'Saturday', '09:29:27', NULL, 15, 2, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (583, 10, 'numtimestables', '2005-06-25', 'Saturday', '16:20:14', NULL, 15, 7, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (584, 10, 'numtimestables', '2005-06-26', 'Sunday', '01:25:56', NULL, 15, 8, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (585, 10, 'numtimestables', '2005-06-26', 'Sunday', '18:32:13', NULL, 15, 2, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (586, 10, 'numtimestables', '2005-06-26', 'Sunday', '20:22:28', NULL, 15, 9, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (587, 10, 'numtimestables', '2005-06-29', 'Wednesday', '22:26:27', NULL, 15, 5, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (588, 10, 'numtimestables', '2005-06-29', 'Wednesday', '23:25:32', NULL, 15, 3, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (589, 10, 'numtimestables', '2005-07-02', 'Saturday', '13:16:47', NULL, 15, 7, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (590, 10, 'numtimestables', '2005-07-04', 'Monday', '09:02:03', NULL, 15, 3, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (591, 10, 'numtimestables', '2005-07-05', 'Tuesday', '21:19:38', NULL, 15, 3, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (592, 10, 'numtimestables', '2005-07-05', 'Tuesday', '21:19:44', NULL, 15, 5, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (593, 10, 'numtimestables', '2005-07-05', 'Tuesday', '21:19:46', NULL, 15, 2, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (594, 10, 'numtimestables', '2005-07-07', 'Thursday', '00:31:08', NULL, 15, 3, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (595, 10, 'numtimestables', '2005-07-09', 'Saturday', '01:15:53', NULL, 15, 3, NULL, 6);
INSERT INTO `PTHomeWork1` VALUES (596, 10, 'numtimestables', '2005-07-10', 'Sunday', '19:31:45', NULL, 15, 9, NULL, 3);
INSERT INTO `PTHomeWork1` VALUES (597, 10, 'numtimestables', '2005-07-12', 'Tuesday', '23:38:40', NULL, 15, 4, NULL, 8);
INSERT INTO `PTHomeWork1` VALUES (598, 10, 'numtimestables', '2005-07-15', 'Friday', '02:19:21', NULL, 15, 7, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (599, 10, 'numtimestables', '2005-07-15', 'Friday', '20:43:50', NULL, 15, 9, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (600, 10, 'numtimestables', '2005-07-16', 'Saturday', '18:13:26', NULL, 15, 3, NULL, 2);
INSERT INTO `PTHomeWork1` VALUES (601, 10, 'numtimestables', '2005-07-17', 'Sunday', '16:34:40', NULL, 15, 4, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (602, 10, 'numtimestables', '2005-07-20', 'Wednesday', '12:39:20', NULL, 15, 8, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (603, 10, 'numtimestables', '2005-07-20', 'Wednesday', '12:39:24', NULL, 15, 7, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (604, 10, 'numtimestables', '2005-07-20', 'Wednesday', '12:44:13', NULL, 15, 3, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (605, 10, 'numtimestables', '2005-07-21', 'Thursday', '01:42:45', NULL, 15, 5, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (606, 10, 'numtimestables', '2005-07-23', 'Saturday', '02:10:37', NULL, 15, 4, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (607, 10, 'numtimestables', '2005-07-24', 'Sunday', '19:50:44', NULL, 15, 9, NULL, 2);
INSERT INTO `PTHomeWork1` VALUES (608, 10, 'numtimestables', '2005-07-25', 'Monday', '00:56:38', NULL, 15, 6, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (609, 10, 'numtimestables', '2005-07-26', 'Tuesday', '22:17:12', NULL, 15, 7, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (610, 10, 'numtimestables', '2005-07-28', 'Thursday', '13:50:53', NULL, 15, 7, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (611, 10, 'numtimestables', '2005-08-01', 'Monday', '07:51:02', NULL, 15, 2, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (612, 10, 'numtimestables', '2005-08-02', 'Tuesday', '12:59:47', NULL, 15, 5, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (613, 10, 'numtimestables', '2005-08-02', 'Tuesday', '16:37:49', NULL, 15, 9, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (614, 10, 'numtimestables', '2005-08-05', 'Friday', '01:59:23', NULL, 15, 6, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (615, 10, 'numtimestables', '2005-08-06', 'Saturday', '22:42:15', NULL, 15, 7, NULL, 11);
INSERT INTO `PTHomeWork1` VALUES (616, 10, 'numtimestables', '2005-08-07', 'Sunday', '14:22:54', NULL, 15, 5, NULL, 2);
INSERT INTO `PTHomeWork1` VALUES (617, 10, 'numtimestables', '2005-08-10', 'Wednesday', '15:43:33', NULL, 15, 6, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (618, 10, 'numtimestables', '2005-08-14', 'Sunday', '03:29:49', NULL, 15, 9, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (619, 10, 'numtimestables', '2005-08-14', 'Sunday', '10:22:53', NULL, 15, 3, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (620, 10, 'numtimestables', '2005-08-16', 'Tuesday', '01:11:58', NULL, 15, 4, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (621, 10, 'numtimestables', '2005-08-16', 'Tuesday', '12:38:16', NULL, 15, 5, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (622, 10, 'numtimestables', '2005-08-16', 'Tuesday', '12:38:45', NULL, 15, 7, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (623, 10, 'numtimestables', '2005-08-16', 'Tuesday', '12:38:45', NULL, 15, 4, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (624, 10, 'numtimestables', '2005-08-16', 'Tuesday', '17:07:30', NULL, 15, 7, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (625, 10, 'numtimestables', '2005-08-19', 'Friday', '19:45:09', NULL, 15, 3, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (626, 10, 'numtimestables', '2005-08-20', 'Saturday', '06:22:21', NULL, 15, 5, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (627, 10, 'numtimestables', '2005-08-21', 'Sunday', '10:53:38', NULL, 15, 2, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (628, 10, 'numtimestables', '2005-08-22', 'Monday', '21:04:59', NULL, 15, 2, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (629, 10, 'numtimestables', '2005-08-23', 'Tuesday', '09:49:19', NULL, 15, 4, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (630, 10, 'numtimestables', '2005-08-24', 'Wednesday', '23:33:49', NULL, 15, 8, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (631, 10, 'numtimestables', '2005-08-29', 'Monday', '18:50:54', NULL, 15, 4, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (632, 10, 'numtimestables', '2005-08-30', 'Tuesday', '21:18:03', NULL, 15, 9, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (633, 10, 'numtimestables', '2005-09-04', 'Sunday', '00:58:07', NULL, 15, 4, NULL, 2);
INSERT INTO `PTHomeWork1` VALUES (634, 10, 'numtimestables', '2005-09-07', 'Wednesday', '20:12:30', NULL, 15, 9, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (635, 10, 'numtimestables', '2005-09-14', 'Wednesday', '20:33:06', NULL, 15, 7, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (636, 10, 'numtimestables', '2005-09-16', 'Friday', '05:17:48', NULL, 15, 9, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (637, 10, 'numtimestables', '2005-09-18', 'Sunday', '02:44:08', NULL, 15, 3, NULL, 4);
INSERT INTO `PTHomeWork1` VALUES (638, 10, 'numtimestables', '2005-09-20', 'Tuesday', '21:58:34', NULL, 15, 7, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (639, 10, 'numtimestables', '2005-09-22', 'Thursday', '01:31:36', NULL, 15, 9, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (640, 10, 'numtimestables', '2005-09-28', 'Wednesday', '16:40:35', NULL, 15, 4, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (641, 10, 'numtimestables', '2005-09-28', 'Wednesday', '19:43:08', NULL, 15, 9, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (642, 10, 'numtimestables', '2005-09-29', 'Thursday', '11:50:29', NULL, 15, 9, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (643, 10, 'numtimestables', '2005-09-29', 'Thursday', '13:08:38', NULL, 15, 3, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (644, 10, 'numtimestables', '2005-09-29', 'Thursday', '13:09:56', NULL, 15, 6, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (645, 10, 'numtimestables', '2005-10-01', 'Saturday', '21:58:13', NULL, 15, 4, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (646, 10, 'numtimestables', '2005-10-06', 'Thursday', '06:37:11', NULL, 15, 9, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (647, 10, 'numtimestables', '2005-10-06', 'Thursday', '13:48:55', NULL, 15, 2, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (648, 10, 'numtimestables', '2005-10-09', 'Sunday', '12:32:14', NULL, 15, 6, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (649, 10, 'numtimestables', '2005-10-10', 'Monday', '00:48:44', NULL, 15, 4, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (650, 10, 'numtimestables', '2005-10-10', 'Monday', '00:49:30', NULL, 15, 7, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (651, 10, 'numtimestables', '2005-10-10', 'Monday', '00:49:32', NULL, 15, 7, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (652, 10, 'numtimestables', '2005-10-10', 'Monday', '02:01:15', NULL, 15, 3, NULL, 5);
INSERT INTO `PTHomeWork1` VALUES (653, 10, 'numtimestables', '2005-10-11', 'Tuesday', '03:06:57', NULL, 15, 9, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (654, 10, 'numtimestables', '2005-10-12', 'Wednesday', '15:42:00', NULL, 15, 7, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (655, 10, 'numtimestables', '2005-10-13', 'Thursday', '16:42:37', NULL, 15, 5, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (656, 10, 'numtimestables', '2005-10-14', 'Friday', '18:08:02', NULL, 15, 8, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (657, 10, 'numtimestables', '2005-10-15', 'Saturday', '03:32:31', NULL, 15, 2, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (658, 10, 'numtimestables', '2005-10-15', 'Saturday', '19:06:12', NULL, 15, 7, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (659, 10, 'numtimestables', '2005-10-16', 'Sunday', '20:57:07', NULL, 15, 4, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (660, 10, 'numtimestables', '2005-10-17', 'Monday', '00:22:41', NULL, 15, 2, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (661, 10, 'numtimestables', '2005-10-18', 'Tuesday', '02:33:42', NULL, 15, 9, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (662, 10, 'numtimestables', '2005-10-18', 'Tuesday', '09:44:33', NULL, 15, 7, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (663, 10, 'numtimestables', '2005-10-19', 'Wednesday', '05:16:02', NULL, 15, 2, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (664, 10, 'numtimestables', '2005-10-19', 'Wednesday', '19:59:49', NULL, 15, 8, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (665, 10, 'numtimestables', '2005-10-20', 'Thursday', '16:52:11', NULL, 15, 3, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (666, 10, 'numtimestables', '2005-10-21', 'Friday', '16:34:49', NULL, 15, 8, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (667, 10, 'numtimestables', '2005-10-26', 'Wednesday', '18:07:47', NULL, 15, 6, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (668, 10, 'numtimestables', '2005-10-31', 'Monday', '21:37:40', NULL, 15, 5, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (669, 10, 'numtimestables', '2005-11-01', 'Tuesday', '19:33:07', NULL, 15, 3, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (670, 10, 'numtimestables', '2005-11-05', 'Saturday', '02:38:57', NULL, 15, 5, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (671, 10, 'numtimestables', '2005-11-06', 'Sunday', '10:39:02', NULL, 15, 3, NULL, 2);
INSERT INTO `PTHomeWork1` VALUES (672, 10, 'numtimestables', '2005-11-08', 'Tuesday', '03:11:50', NULL, 15, 6, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (673, 10, 'numtimestables', '2005-11-23', 'Wednesday', '04:17:19', NULL, 15, 8, NULL, 1);
INSERT INTO `PTHomeWork1` VALUES (674, 10, 'numtimestables', '2005-11-24', 'Thursday', '01:16:57', NULL, 15, 7, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (675, 10, 'numtimestables', '2005-12-01', 'Thursday', '18:34:51', NULL, 15, 3, NULL, 2);
INSERT INTO `PTHomeWork1` VALUES (676, 10, 'numtimestables', '2005-12-04', 'Sunday', '07:31:21', NULL, 15, 4, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (677, 10, 'numtimestables', '2005-12-07', 'Wednesday', '01:32:17', NULL, 15, 9, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (678, 10, 'numtimestables', '2005-12-08', 'Thursday', '16:00:45', NULL, 15, 9, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (679, 10, 'numtimestables', '2005-12-12', 'Monday', '21:46:36', NULL, 15, 4, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (680, 10, 'numtimestables', '2005-12-13', 'Tuesday', '04:41:54', NULL, 15, 3, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (681, 10, 'numtimestables', '2005-12-17', 'Saturday', '05:15:36', NULL, 15, 2, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (682, 10, 'numtimestables', '2005-12-21', 'Wednesday', '14:31:46', NULL, 15, 2, NULL, 0);
INSERT INTO `PTHomeWork1` VALUES (683, 10, 'numtimestables', '2005-12-25', 'Sunday', '17:12:35', NULL, 15, 2, NULL, 0);

-- --------------------------------------------------------

-- 
-- Table structure for table `PTMissedApp`
-- 

CREATE TABLE `PTMissedApp` (
  `id` tinyint(3) unsigned NOT NULL auto_increment,
  `sid` tinyint(3) unsigned NOT NULL default '0',
  `date` date NOT NULL default '0000-00-00',
  PRIMARY KEY  (`id`)
) TYPE=MyISAM AUTO_INCREMENT=43 ;

-- 
-- Dumping data for table `PTMissedApp`
-- 

INSERT INTO `PTMissedApp` VALUES (1, 0, '2003-09-15');
INSERT INTO `PTMissedApp` VALUES (2, 0, '2003-09-16');
INSERT INTO `PTMissedApp` VALUES (3, 2, '2003-09-17');
INSERT INTO `PTMissedApp` VALUES (4, 5, '2003-09-09');
INSERT INTO `PTMissedApp` VALUES (5, 12, '2003-10-27');
INSERT INTO `PTMissedApp` VALUES (6, 15, '2003-10-15');
INSERT INTO `PTMissedApp` VALUES (7, 13, '2003-10-20');
INSERT INTO `PTMissedApp` VALUES (8, 4, '2003-10-28');
INSERT INTO `PTMissedApp` VALUES (9, 6, '2003-10-30');
INSERT INTO `PTMissedApp` VALUES (10, 0, '2003-11-05');
INSERT INTO `PTMissedApp` VALUES (11, 0, '2003-11-06');
INSERT INTO `PTMissedApp` VALUES (12, 0, '2003-11-10');
INSERT INTO `PTMissedApp` VALUES (13, 0, '2003-11-18');
INSERT INTO `PTMissedApp` VALUES (14, 0, '2003-11-24');
INSERT INTO `PTMissedApp` VALUES (15, 0, '2003-11-25');
INSERT INTO `PTMissedApp` VALUES (16, 0, '2003-11-27');
INSERT INTO `PTMissedApp` VALUES (17, 0, '2003-11-28');
INSERT INTO `PTMissedApp` VALUES (18, 0, '2003-11-26');
INSERT INTO `PTMissedApp` VALUES (19, 11, '2003-11-04');
INSERT INTO `PTMissedApp` VALUES (20, 14, '2003-11-23');
INSERT INTO `PTMissedApp` VALUES (21, 0, '2003-12-03');
INSERT INTO `PTMissedApp` VALUES (22, 1, '2003-12-02');
INSERT INTO `PTMissedApp` VALUES (23, 13, '2003-12-15');
INSERT INTO `PTMissedApp` VALUES (27, 1, '2004-01-13');
INSERT INTO `PTMissedApp` VALUES (25, 5, '2004-01-14');
INSERT INTO `PTMissedApp` VALUES (26, 5, '2004-01-21');
INSERT INTO `PTMissedApp` VALUES (28, 1, '2004-01-27');
INSERT INTO `PTMissedApp` VALUES (29, 12, '2004-01-19');
INSERT INTO `PTMissedApp` VALUES (30, 12, '2004-01-26');
INSERT INTO `PTMissedApp` VALUES (31, 3, '2004-01-20');
INSERT INTO `PTMissedApp` VALUES (32, 0, '2004-02-16');
INSERT INTO `PTMissedApp` VALUES (33, 0, '2004-02-17');
INSERT INTO `PTMissedApp` VALUES (34, 1, '2004-02-03');
INSERT INTO `PTMissedApp` VALUES (35, 10, '2004-02-02');
INSERT INTO `PTMissedApp` VALUES (36, 13, '2004-02-26');
INSERT INTO `PTMissedApp` VALUES (37, 13, '2004-02-12');
INSERT INTO `PTMissedApp` VALUES (38, 11, '2004-03-17');
INSERT INTO `PTMissedApp` VALUES (39, 12, '2004-05-18');
INSERT INTO `PTMissedApp` VALUES (40, 2, '2004-06-26');
INSERT INTO `PTMissedApp` VALUES (41, 2, '2004-05-26');
INSERT INTO `PTMissedApp` VALUES (42, 1, '2004-05-05');

-- --------------------------------------------------------

-- 
-- Table structure for table `PTSchedInfo`
-- 

CREATE TABLE `PTSchedInfo` (
  `id` tinyint(3) unsigned NOT NULL auto_increment,
  `sid` tinyint(3) unsigned NOT NULL default '0',
  `name` varchar(40) default NULL,
  `rate` decimal(6,2) NOT NULL default '0.00',
  `dow` enum('Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday') NOT NULL default 'Monday',
  `hours` decimal(4,2) NOT NULL default '0.00',
  `start_date` date NOT NULL default '0000-00-00',
  `end_date` date NOT NULL default '0000-00-00',
  `comments` varchar(100) default NULL,
  PRIMARY KEY  (`id`)
) TYPE=MyISAM AUTO_INCREMENT=42 ;

-- 
-- Dumping data for table `PTSchedInfo`
-- 

INSERT INTO `PTSchedInfo` VALUES (1, 2, 'Bekins Milo', 100.00, 'Wednesday', 1.00, '2003-09-02', '2003-12-22', '');
INSERT INTO `PTSchedInfo` VALUES (2, 5, 'Cohen Ilana', 100.00, 'Tuesday', 1.00, '2003-09-01', '2003-11-09', '');
INSERT INTO `PTSchedInfo` VALUES (3, 1, 'Crews Andy', 100.00, 'Tuesday', 1.00, '2003-09-01', '2003-12-22', '');
INSERT INTO `PTSchedInfo` VALUES (9, 9, 'Devor Eric', 100.00, 'Monday', 1.00, '2003-09-08', '2003-11-05', '');
INSERT INTO `PTSchedInfo` VALUES (5, 4, 'Heath Joel', 100.00, 'Tuesday', 1.00, '2003-09-01', '2003-09-10', '');
INSERT INTO `PTSchedInfo` VALUES (6, 4, 'Heath Joel', 92.50, 'Tuesday', 2.00, '2003-09-14', '2003-12-22', '');
INSERT INTO `PTSchedInfo` VALUES (7, 3, 'Kendall Chris', 100.00, 'Tuesday', 1.25, '2003-09-13', '2003-12-20', '');
INSERT INTO `PTSchedInfo` VALUES (8, 13, 'Omick Jake', 100.00, 'Wednesday', 1.00, '2003-09-16', '2003-10-17', '');
INSERT INTO `PTSchedInfo` VALUES (11, 12, 'Gina D', 100.00, 'Monday', 1.00, '2003-09-07', '2003-12-15', '');
INSERT INTO `PTSchedInfo` VALUES (12, 10, 'Nick O''neal', 100.00, 'Monday', 1.00, '2003-09-21', '2003-12-15', '');
INSERT INTO `PTSchedInfo` VALUES (18, 13, 'Omick', 100.00, 'Monday', 1.00, '2003-10-26', '2003-12-15', '');
INSERT INTO `PTSchedInfo` VALUES (14, 6, 'Goodwin, Sophie', 100.00, 'Thursday', 1.00, '2003-09-24', '2003-10-31', '');
INSERT INTO `PTSchedInfo` VALUES (15, 11, 'Williams, Adam', 100.00, 'Wednesday', 1.00, '2003-09-21', '2003-12-20', '');
INSERT INTO `PTSchedInfo` VALUES (16, 14, 'Peter True', 100.00, 'Sunday', 1.00, '2003-10-19', '2003-12-20', '');
INSERT INTO `PTSchedInfo` VALUES (17, 15, 'Mat Wood', 75.00, 'Wednesday', 1.00, '2003-10-01', '2003-10-31', '');
INSERT INTO `PTSchedInfo` VALUES (21, 5, 'Ilana', 100.00, 'Wednesday', 1.00, '2003-11-10', '2003-12-20', '');
INSERT INTO `PTSchedInfo` VALUES (20, 11, 'Williams Adam', 100.00, 'Tuesday', 1.00, '2003-10-07', '2003-12-18', '');
INSERT INTO `PTSchedInfo` VALUES (22, 1, 'Crews', 100.00, 'Tuesday', 1.00, '2004-01-05', '2004-02-22', '');
INSERT INTO `PTSchedInfo` VALUES (23, 12, 'De Tomasi', 100.00, 'Monday', 1.00, '2004-01-05', '2004-02-08', '');
INSERT INTO `PTSchedInfo` VALUES (24, 4, 'Heath', 92.50, 'Tuesday', 2.00, '2004-01-05', '2004-06-05', '');
INSERT INTO `PTSchedInfo` VALUES (25, 3, 'Kendall', 100.00, 'Tuesday', 1.00, '2004-01-16', '2004-01-28', '');
INSERT INTO `PTSchedInfo` VALUES (26, 3, 'Kendall', 100.00, 'Tuesday', 1.40, '2004-02-01', '2004-02-18', '');
INSERT INTO `PTSchedInfo` VALUES (27, 10, 'O''Neal', 100.00, 'Monday', 1.00, '2004-01-04', '2004-02-29', '');
INSERT INTO `PTSchedInfo` VALUES (28, 13, 'Omick', 100.00, 'Wednesday', 1.00, '2004-01-20', '2004-01-22', '');
INSERT INTO `PTSchedInfo` VALUES (29, 13, 'Omick', 100.00, 'Thursday', 1.00, '2004-02-01', '2004-02-20', '');
INSERT INTO `PTSchedInfo` VALUES (30, 14, 'True', 100.00, 'Sunday', 1.00, '2004-01-10', '2004-03-16', '');
INSERT INTO `PTSchedInfo` VALUES (31, 11, 'Williams', 100.00, 'Tuesday', 1.00, '2004-01-04', '2004-06-05', '');
INSERT INTO `PTSchedInfo` VALUES (32, 11, 'Williams', 100.00, 'Wednesday', 1.00, '2004-01-04', '2004-06-05', '');
INSERT INTO `PTSchedInfo` VALUES (33, 2, 'Milo', 100.00, 'Wednesday', 1.00, '2004-01-04', '2004-01-27', '');
INSERT INTO `PTSchedInfo` VALUES (34, 2, 'Milo', 100.00, 'Wednesday', 1.25, '2004-01-28', '2004-06-05', '');
INSERT INTO `PTSchedInfo` VALUES (35, 5, 'Cohen', 100.00, 'Wednesday', 1.00, '2004-01-11', '2004-06-05', '');
INSERT INTO `PTSchedInfo` VALUES (36, 1, 'Crews', 100.00, 'Wednesday', 1.00, '2004-02-22', '2004-06-05', '');
INSERT INTO `PTSchedInfo` VALUES (37, 12, 'De Tomasi', 100.00, 'Tuesday', 1.00, '2004-03-01', '2004-06-05', '');
INSERT INTO `PTSchedInfo` VALUES (38, 12, 'De Tomasi', 100.00, 'Wednesday', 1.00, '2004-02-08', '2004-02-29', '');
INSERT INTO `PTSchedInfo` VALUES (39, 3, 'Kendall', 100.00, 'Tuesday', 1.00, '2004-02-18', '2004-04-10', '');
INSERT INTO `PTSchedInfo` VALUES (40, 16, 'Daniella Pineda', 100.00, 'Thursday', 2.00, '2004-03-01', '2004-06-05', '');

-- --------------------------------------------------------

-- 
-- Table structure for table `PTStudentInfo`
-- 

CREATE TABLE `PTStudentInfo` (
  `id` smallint(6) NOT NULL auto_increment,
  `last_name` varchar(25) NOT NULL default '',
  `first_name` varchar(20) NOT NULL default '',
  `birthday` date default '0000-00-00',
  `phone` varchar(25) default NULL,
  `email` varchar(45) default NULL,
  `fid` tinyint(4) default '0',
  `student` varchar(20) default NULL,
  PRIMARY KEY  (`id`)
) TYPE=MyISAM COMMENT='fid' AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `PTStudentInfo`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `PTStudentInfo_New`
-- 

CREATE TABLE `PTStudentInfo_New` (
  `id` smallint(6) NOT NULL auto_increment,
  `last_name` varchar(25) NOT NULL default '',
  `first_name` varchar(20) NOT NULL default '',
  `birthday` date default '0000-00-00',
  `phone` varchar(25) default NULL,
  `email` varchar(45) default NULL,
  `fid` tinyint(4) default '0',
  `student` varchar(20) default NULL,
  PRIMARY KEY  (`id`)
) TYPE=MyISAM COMMENT='fid' AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `PTStudentInfo_New`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `PTStudentInfo_Old`
-- 

CREATE TABLE `PTStudentInfo_Old` (
  `lastname` varchar(40) NOT NULL default '',
  `id` tinyint(3) unsigned NOT NULL auto_increment,
  `student` varchar(20) NOT NULL default '',
  `student2` varchar(30) default NULL,
  `student3` varchar(30) default NULL,
  `moms_name` varchar(40) default NULL,
  `dads_name` varchar(40) default NULL,
  `billing_name` varchar(40) NOT NULL default '',
  `parents_email` varchar(50) default NULL,
  `billing_email` varchar(50) default NULL,
  `students_email` varchar(50) default NULL,
  `home_phone` varchar(13) default NULL,
  `cell_phone` varchar(13) default NULL,
  `work_phone` varchar(20) default NULL,
  `other_phone` varchar(20) default NULL,
  `students_phone` varchar(13) default NULL,
  `username` varchar(10) NOT NULL default '',
  `password` varchar(8) NOT NULL default '',
  `address` varchar(40) default NULL,
  `address2` varchar(40) default NULL,
  `city` varchar(20) default NULL,
  `zip` varchar(10) default NULL,
  `comments` varchar(100) default NULL,
  PRIMARY KEY  (`id`)
) TYPE=MyISAM AUTO_INCREMENT=17 ;

-- 
-- Dumping data for table `PTStudentInfo_Old`
-- 

INSERT INTO `PTStudentInfo_Old` VALUES ('Crews', 1, 'Andy', NULL, NULL, 'Vanessa', '', 'Vanessa', 'crewsn6@attbi.com', 'crewsn6@attbi.com', '', '', '', '', '', '', 'Andy140', '411', '', '', '', '', '');
INSERT INTO `PTStudentInfo_Old` VALUES ('Bekins', 2, 'Milo', NULL, NULL, 'Kate Bekins', '', 'Kate Bekins', 'KBEKINSLAW@sbcglobal.net', 'KBEKINSLAW@sbcglobal.net', '', '', '', '', '', '', 'Milo240', '147', '', '', '', '', '');
INSERT INTO `PTStudentInfo_Old` VALUES ('Kendall', 3, 'Chris', 'Rylan', '', 'Jane', '', 'Jane', 'mjkendall@attbi.com', 'mjkendall@attbi.com', '', '', '', '', '', '', 'Chris340', '501', '', '', '', '', '');
INSERT INTO `PTStudentInfo_Old` VALUES ('Heath', 4, 'Joel', 'Ian', '', 'Laury', '', 'Laury', 'LLJH54@aol.com', 'LLJH54@aol.com', '', '', '', '', '', '', 'Joel440', '63', '', '', '', '', '');
INSERT INTO `PTStudentInfo_Old` VALUES ('Cohen', 5, 'Ilana', '', '', 'Tal', 'Tom', 'Tal', 'tomcohen@silcon.com', 'tomcohen@silcon.com', '', '', '', '', '', '', 'Ilana540', '813', '', '', '', '', '');
INSERT INTO `PTStudentInfo_Old` VALUES ('Goodwin', 6, 'Sophie', '', '', 'Stella', '', 'Stella', 'stellajg@yahoo.com', 'stellajg@yahoo.com', '', '', '', '', '', '', 'Sophie640', '874', '', '', '', '', '');
INSERT INTO `PTStudentInfo_Old` VALUES ('Harmon', 7, 'William', 'Danny', '', 'Megan Tootell', '', 'Megan Tootell', 'matootell@aol.com', 'matootell@aol.com', '', '', '', '', '', '', 'William740', '933', '', '', '', '', '');
INSERT INTO `PTStudentInfo_Old` VALUES ('Devor', 9, 'Eric', '', '', 'Sally', '', 'Sally', 'SDevor95@aol.com', 'SDevor95@aol.com', '', '', '', '', '', '', 'Eric940', '409edr', '', '', '', '', '');
INSERT INTO `PTStudentInfo_Old` VALUES ('O''Neal', 10, 'Nick', NULL, NULL, 'Shelly', 'Brian', 'Shelly', 'sgo1986@comcast.net', 'sgo1986@comcast.net', NULL, NULL, NULL, NULL, NULL, NULL, 'Nick420', 'on821p', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `PTStudentInfo_Old` VALUES ('Williams', 11, 'Adam', NULL, NULL, '', 'Will', 'Lou Ann', 'will.williams@sbcglobal.net', 'la.williams@comcast.net', NULL, NULL, NULL, NULL, NULL, NULL, 'Adam22', '23fd55', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `PTStudentInfo_Old` VALUES ('De Tomasi', 12, 'Gina', NULL, NULL, 'Lia', 'Mario', 'Lia De Tomasi', 'ldetomasi@comcast.net', 'ldetomasi@comcast.net', NULL, '9252837630', NULL, NULL, NULL, NULL, 'GinaD44', '34rp', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `PTStudentInfo_Old` VALUES ('Omick', 13, 'Jake', NULL, NULL, 'Jane', 'Brad', 'Brad Omick', 'HOW2BCRE8V@aol.com; RACEZ8@aol.com', 'RACEZ8@aol.com', NULL, NULL, NULL, NULL, NULL, NULL, 'JO221', '14tt8', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `PTStudentInfo_Old` VALUES ('True', 14, 'Peter', NULL, NULL, 'Claudia Wilken', NULL, 'Claudia Wilken', 'Claudiawilken@aol.com', 'Claudiawilken@aol.com', 'pwtrue@aol.com', NULL, NULL, NULL, NULL, '5107016001', 'ptr899', 'c44tru', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `PTStudentInfo_Old` VALUES ('Wood', 15, 'Mat', NULL, NULL, 'Susan', NULL, 'Susan', 'Sucott@aol.com', 'Sucott@aol.com', NULL, NULL, NULL, NULL, NULL, NULL, 'mwood23', 'WWWp99', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `PTStudentInfo_Old` VALUES ('Klein', 16, 'Daniella Pineda', NULL, NULL, NULL, 'Robert', 'Robert Klein', 'esklein@appliedenviro.com', 'esklein@appliedenviro.com', NULL, NULL, NULL, NULL, NULL, NULL, 'Rkle40', 'r5tt4', NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

-- 
-- Table structure for table `PTTeachers`
-- 

CREATE TABLE `PTTeachers` (
  `id` tinyint(3) unsigned NOT NULL auto_increment,
  `sid` tinyint(3) unsigned NOT NULL default '0',
  `student` varchar(25) NOT NULL default '',
  `firstname` varchar(15) NOT NULL default '',
  `lastname` varchar(20) NOT NULL default '',
  `email` varchar(40) NOT NULL default '',
  `subject` varchar(15) NOT NULL default '',
  PRIMARY KEY  (`id`)
) TYPE=MyISAM AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `PTTeachers`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `PTTestimonials`
-- 

CREATE TABLE `PTTestimonials` (
  `id` smallint(6) NOT NULL auto_increment,
  `comments` varchar(200) NOT NULL default '',
  `name` varchar(30) default 'anonymous',
  `relation` set('student','parent','teacher','educational consultant','other') NOT NULL default '',
  `school` varchar(30) NOT NULL default '',
  `grad_year` tinyint(4) NOT NULL default '0',
  `school2` varchar(30) default NULL,
  `grad_year2` tinyint(4) default NULL,
  `school3` varchar(30) default NULL,
  `grad_year3` tinyint(4) default NULL,
  PRIMARY KEY  (`id`)
) TYPE=MyISAM AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `PTTestimonials`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `PTVacations`
-- 

CREATE TABLE `PTVacations` (
  `id` tinyint(4) NOT NULL auto_increment,
  `start_date` date NOT NULL default '0000-00-00',
  `end_date` date NOT NULL default '0000-00-00',
  `other` varchar(10) default NULL,
  PRIMARY KEY  (`id`)
) TYPE=MyISAM AUTO_INCREMENT=3 ;

-- 
-- Dumping data for table `PTVacations`
-- 

INSERT INTO `PTVacations` VALUES (1, '2004-03-29', '2004-04-02', NULL);
INSERT INTO `PTVacations` VALUES (2, '2004-04-09', '2004-04-30', NULL);

-- --------------------------------------------------------

-- 
-- Table structure for table `PT_Family_Info`
-- 

CREATE TABLE `PT_Family_Info` (
  `id` smallint(6) NOT NULL auto_increment,
  `mother` varchar(40) default NULL,
  `father` varchar(40) default NULL,
  `guardian` varchar(40) default NULL,
  `main_contact` enum('mother','father','guardian') NOT NULL default 'mother',
  `billing_name` varchar(20) default NULL,
  `username` varchar(10) NOT NULL default '',
  `password` varchar(10) NOT NULL default '',
  `main_phone` varchar(30) NOT NULL default '',
  `mothers_phone` varchar(30) default NULL,
  `fathers_phone` varchar(30) default NULL,
  `billing_email` varchar(50) NOT NULL default '',
  `mothers_email` varchar(50) default NULL,
  `fathers_email` varchar(50) default NULL,
  `number_of_students` tinyint(4) NOT NULL default '1',
  `sid1` smallint(6) default NULL,
  `sid2` smallint(6) default NULL,
  `sid3` smallint(6) default NULL,
  `sid4` smallint(6) default NULL,
  `address` varchar(75) NOT NULL default '',
  `city` varchar(25) NOT NULL default '',
  `state` char(2) NOT NULL default 'CA',
  `zip` varchar(5) NOT NULL default '',
  PRIMARY KEY  (`id`),
  FULLTEXT KEY `guardian` (`guardian`)
) TYPE=MyISAM COMMENT='sid1,sid2,sid3,sid4' AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `PT_Family_Info`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `PT_Table_Info`
-- 

CREATE TABLE `PT_Table_Info` (
  `id` tinyint(4) NOT NULL auto_increment,
  `name` varchar(50) NOT NULL default '',
  `ignore_fields` varchar(200) default NULL,
  PRIMARY KEY  (`id`)
) TYPE=MyISAM COMMENT='this is the information about each table' AUTO_INCREMENT=4 ;

-- 
-- Dumping data for table `PT_Table_Info`
-- 

INSERT INTO `PT_Table_Info` VALUES (1, 'PTStudentInfo', 'fid,student');
INSERT INTO `PT_Table_Info` VALUES (2, 'PT_Family_Info', 'billing_name, Number_of_students, sid1, sid2, sid3, sid4');
INSERT INTO `PT_Table_Info` VALUES (3, 'PTTeachers', 'student,sid');

-- --------------------------------------------------------

-- 
-- Table structure for table `thepadc_ht100_compend`
-- 

CREATE TABLE `thepadc_ht100_compend` (
  `id` smallint(6) NOT NULL auto_increment,
  `word` varchar(50) NOT NULL default '',
  `definition` text NOT NULL,
  `source` varchar(50) default NULL,
  `alternates` varchar(255) default NULL,
  `counter` smallint(6) NOT NULL default '0',
  `links` varchar(250) default NULL,
  `links_title` varchar(50) default NULL,
  `cleared` char(3) default NULL,
  PRIMARY KEY  (`id`)
) TYPE=MyISAM AUTO_INCREMENT=62 ;

-- 
-- Dumping data for table `thepadc_ht100_compend`
-- 

INSERT INTO `thepadc_ht100_compend` VALUES (19, 'brain', 'The brain is the physical "grey matter" locate within the skull.  It is the actual biological organ that is largely responsible for thought and cognition.\r\n\r\nThis is as opposed to the "Mind", which is not an actual physical things, but the psychological processes a person goes through that make up the foundations of cognition and thought.', 'Paul Osborne', '', 2, '', '', 'yes');
INSERT INTO `thepadc_ht100_compend` VALUES (20, 'mind', 'The psychological processes a person goes through that make up the foundations of cognition and thought.  This is as opposed to the "Brain", which is the actual physical structure that does the thinking.', 'Paul Osborne', '', 1, '', '', 'yes');
INSERT INTO `thepadc_ht100_compend` VALUES (30, 'zone of proximal development', '(ZPD) a Vygotskian term which refers to the difference between one''s actual ability to learn as determined by independent accomplishments and their level of potential learning as determined by asisted or scaffolded accomplishments.  In essence, the ZPD is the difference between what someone can do by themselves and what they can do with helped.<BR><BR>There are three main implications of the ZPD for education.  First, students left to learn on their own, and develop at their own pace will not gain as much as those who are assisted.  Second, the areas in which a student is guided will be the areas in which he has the opportunity to gain the most knowledge and the greatest development.  Third, in order to provide students with adequate difficulty in learning, yet not overburden them, their work load must reside within the ZPD.', 'Paul Osborne', 'ZPD', 1, 'http://en.wikipedia.org/wiki/ZPD', 'Wikipedia', 'yes');
INSERT INTO `thepadc_ht100_compend` VALUES (31, 'heuristic', 'Problem solving strategy that tend to aid in solving of problems in general.  This is as opposed to an algorithm which, when followed, definitely solve particular problems.<BR><BR>heuristic -- Find a similar problem and see if it applies to your problem.<br>algorithm -- FOIL (x+3)(x-2).', 'Paul Osborne', 'heuristics', 1, '', '', 'yes');
INSERT INTO `thepadc_ht100_compend` VALUES (32, 'autism', 'A developmental disorder characterized both by impaired abilities to form normal social relationships, communicate with others, and recognize social norms and cues, as well as by a propensity and preference for repetitive behavior patterns.', 'Courtney Zaleski', 'autistic, autism spectrum', 1, 'www.autism.com', 'www.autism.com', 'yes');
INSERT INTO `thepadc_ht100_compend` VALUES (34, 'cognition', 'Conscious mental activity or processes such as thinking, reasoning, remembering, imagining, or explicit learning.\r\n\r\n\r\n', 'Paul Osborne', 'cognitive processes, cognitive', 1, '', '', 'yes');
INSERT INTO `thepadc_ht100_compend` VALUES (35, 'scaffolding', 'Help in thinking, learning, deducing or problem solving.  <BR><BR>Initially the scaffolder provides high levels of support, and then gradually scales back the assistance as the scaffolded learner gains competence.  As the learner builds her understanding, the scaffolder gives just enough aid that the learner can continue to build.', 'Paul Osborne', 'scaffold', 1, '', '', 'yes');
INSERT INTO `thepadc_ht100_compend` VALUES (36, 'attachment', 'Psychology''s version of love.  The desire one has to maintain relationships with loved ones.', 'Paul Osborne', '', 1, '', '', 'yes');
INSERT INTO `thepadc_ht100_compend` VALUES (37, 'abstraction', 'An idealized, non-real conceptualization of something.  An idea of some thing or group of things that contains only the most essential core characteristics.<BR><BR>  An abstraction is generally used in philosophical as opposed to practical discussions because it allows for the discussion of things at their essence, and removes many of the entanglements that accompany working with actual examples.', 'Paul Osborne', '', 1, '', '', 'yes');
INSERT INTO `thepadc_ht100_compend` VALUES (38, 'Piaget, Jean', 'A Swiss professor of psychology who postulated cognitive development happened through a series of stages.  The four main stages: <BR>Sensory Motor, (experienced through senses), <BR>Pre-Operational,(motor skills) <BR>Concrete Operations,(logical thought about actual things) <BR> Formal Operations(abstract reasoning).<BR><BR> Evidence has shown that the Piagetian developmental model of linear development across all domains happening at once, and never regressing does not in fact take place.  Instead, development takes place in different domains or areas of thinking incrementally at numerous points in time in a two steps forward, one step back fashion.\r\n<BR><BR>\r\nThe main implication of Piaget''s work, and what still stands as a guide is the idea that students are biologically ready to understand different concepts at different points in time.  This is as opposed to youths being little cognitive replicas of adults who simply lacked knowledge and education.\r\n', 'Paul Osborne', '"Jean Piaget", piaget, Piaget', 1, 'http://en.wikipedia.org/wiki/Jean_Piaget', 'Wikipedia', 'yes');
INSERT INTO `thepadc_ht100_compend` VALUES (39, 'domain', 'An area of thought or functioning that requires the same type of thinking and deals with the same type of inputs and actions.  Mathematics, conversation or playing the piano might all be considered domains.  As a domain is defined by the subjective notion of what type of thinking is involved, the determination of what is and is not a domain is by definition subjective.\r\n<BR><BR>Domains are most commonly dealt with in conversations of domain general and domain specific.  Domain general refers to types of thinking that might apply to all areas of thought.  One who believes in a core intelligence that makes one mentally fitter overall might call that domain general intelligence in that it is an intelligence that applies generally across domains.  One who believes that mathematical thinking is completely separate from language acquisition abilities, and believes that one''s abilities in one would be irrelevant to one''s ability in the other might refer to domain specific mathematical and domain specific language acquisitional intelligences.\r\n', 'Paul Osborne', 'domains, Domain', 1, '', '', 'yes');
INSERT INTO `thepadc_ht100_compend` VALUES (40, 'Vygotsky, Lev', 'A Russian developmental psychologist who pioneered the notion that development was not guided merely by the individual''s own makeup and timetable, but also by his surroundings and interactions.  Vygotsky''s idea of a "zone of proximal development" stated that what a student could learn or do on his own was far less than what he could learn if he was assisted or "scaffolded".  This notion implied that by guiding a student, the community not only improved a students learning, but increased the child''s development in particular areas, thereby both improving and guiding the direction of development.\r\n<BR><BR>\r\nVygotsky''s  ideas are important in that they allowed for both the Piagetian, maturational notion that children develop on their own, and the theory of behaviorism that children are open to any modification by their surroundings.  The educational implications of Vygotsky''s theories are numerous, but one of the main ones is that education can be important not only for the dissemination of knowledge, but for the promotion, stimulation and direction of intellectual development.\r\n', 'Paul Osborne', 'Vigotsky, Vigotski, "Lev Vygotsky", "Vygogotsky,", Lev, Vygotskian', 1, 'http://www.newfoundations.com/GALLERY/Vygotsky.html', 'Educational Theories of Lev Vygotsky', 'yes');
INSERT INTO `thepadc_ht100_compend` VALUES (41, 'lexicon', 'Mental warehouse of words.', 'Courtney Zaleski and Paul Osborne', '', 1, '', '', 'yes');
INSERT INTO `thepadc_ht100_compend` VALUES (42, 'double deficit', 'Children who have trouble distinguishing phonemes, and have trouble with rapid automatic naming.', 'Paul Osborne', '', 1, 'http://www.apa.org/monitor/mar00/dyslexia.html', 'http://www.apa.org/monitor/mar00/dyslexia.html', 'yes');
INSERT INTO `thepadc_ht100_compend` VALUES (43, 'recursion', '(think recur or reoccur)<BR>Recursion is the process a procedure goes through when one of the steps of the procedure involves rerunning the entire same procedure. A procedure that goes through recursion is said to be recursive. Something is also said to be recursive when it is the result of a recursive procedure.\r\n<BR><BR>\r\nTo understand recursion, one must recognize the distinction between a procedure and the running of a procedure. A procedure is a set of steps that are to be taken based on a set of rules. The running of a procedure involves actually following the rules and performing the steps. An analogy might be that a procedure is like a menu in that it is the possible steps, while running a procedure is actually choosing the courses for the meal from the menu.\r\n<BR><BR>\r\nA procedure is recursive if one of the steps that makes up the procedure calls for a new running of the procedure. Therefore a recursive four course meal would be a meal in which one of the choices of appetizer, salad, entr�e, or dessert was an entire meal unto itself. So a recursive meal might be potato skins, baby greens salad, chicken parmesan, and for dessert, a four course meal, consisting of crab cakes, Caesar salad, for an entr�e, a four course meal, and chocolate cake for dessert, so on until each of the meals within the meals is completed.\r\n<BR><BR>\r\nIt is important to note that a recursive procedure must complete every one of its steps. Even if a new running is called in one of its steps, each running must run through the remaining steps. What this means is that even if the salad is an entire four course meal unto itself, you still have to eat your entr�e and dessert.\r\n<BR><BR> \r\nOne common type of recursion seen in linguistics which many argue is exclusive to humans is a procedure designed to choose successive words to create sentences.  The procedure has three stages.  The first stage, made up of many steps, chooses a the next word for the sentence based on the rules of grammar, available lexicon, the idea to convey, the words that are already in the sentence, and any other set that might effect what word is chosen.  This an extremely complicated stage.  The second stage determines if the sentence is complete or not.  If the sentence is complete, it terminates the running without calling another running, thereby terminating the recursive process.  If the sentence needs more words, the running goes to the third stage, which calls a new running of the procedure, which will choose a new word based on all of the same rules as last time, except the sentence will now be one word longer.\r\n', 'Paul Osborne and Noam Chomsky', 'recursive, recurssive, recurssion', 1, '', '', 'yes');
INSERT INTO `thepadc_ht100_compend` VALUES (44, 'constructivism', 'the pedagogical theory that students need to construct their own understanding, as opposed to assimilating or conforming to that of others.  The role of teaching therefore is not to transfer or impart knowledge, but to present students with, and guide them through situations that allow and foster their own individual building of understanding.  One of the main educational ramifications of constructivism is tailoring learning to the manners in which students develop understanding.  This is as opposed to the more traditional focus which is determining what information is to be acquired, assisting students'' acquisition of it, and testing whether or not they have mastered it.', 'Paul Osborne', 'constructivist', 1, 'http://carbon.cudenver.edu/~mryder/itc_data/constructivism.html', 'C U Denver School of Education', 'yes');
INSERT INTO `thepadc_ht100_compend` VALUES (45, 'compendium', 'a work that provides descriptions and definitions of the important features, terms and characters of a field of knowledge or area of study', 'Paul Osborne', '"mbe compendium"', 1, 'http://www.merriam-webster.com/cgi-bin/dictionary?book=Dictionary&va=compendium', 'Merriam-Webster Online', 'yes');
INSERT INTO `thepadc_ht100_compend` VALUES (46, 'assimilation', 'In the writings of Jean Piaget, a form of adaptation in which novel experiences are incorporated in existing psychological structures of processes, as when an infant responds to a new toy that is introduced to its environment by treating it like an already familiar object, interpreting it as something to be grasped, shaken, put in the mouth and so on.', 'Dictionary of Psychology, 2001, A. Colman ed.', 'asimilation, assimilate, asimilate', 1, '', '', NULL);
INSERT INTO `thepadc_ht100_compend` VALUES (47, 'Accommodation', 'According to Piaget, a form of adaptation in which psychological structures or processes are modified to fit the changing demands of the environment, as when an infant adapts its perceptual processes and behavioral repertoire to a new toy that is introduced into its milieu', 'Dictionary of Psychology, 2001, A. Colman ed.', '', 1, '', '', NULL);
INSERT INTO `thepadc_ht100_compend` VALUES (48, 'algorithm', 'rules or procedures which provide the solution to a particular problem.  FOILing (first, outside, inside, last) is an algorithm for solving math problems such as (x + 4)(x � 3).  \r\n<BR><BR>\r\nThis is as opposed to a heuristic, which is general problem solving strategy which increases the chances of solving many problems.  If one is given the advice, "When multiplying sums, it is important to ensure that every number in one of the sums is multiplied by each member of the other sum," then one has been give a heuristic for solving any problem that involves multiplying to groups of numbers that have been added together.\r\n', 'Paul Osborne', 'algorithmic', 1, '', '', 'yes');
INSERT INTO `thepadc_ht100_compend` VALUES (49, 'neural network', 'A neural network is a network, crisscrossed circuitry, of neurons, entities which respond to particular inputs by firing or releasing a particular output to a particular location.  Generally speaking there are two common classes of neural networks, biological, such as the brain, and artificial, such as computer neural networks.\r\n<BR><BR>\r\nThese networks are made up of input neurons , hidden or middle neurons, and output neurons.  Input neurons respond to some set of inputs by releasing a signal, chemical or electric, depending on the type of network.  Any middle neurons which are connected to the input neuron are encouraged to fire, or inhibited from firing by the input neurons release.  A middle neuron may be connected to many different input neurons all responding to various inputs and input neurons.  This means that any middle neuron is responding to a variety of signals that promote or inhibit its firing.  It is the sum of the promotional and inhibitory signals that determines whether or not it will fire.  Any number of neurons might be signaled either positively or negatively by its firing.  \r\n<BR><BR>\r\nAt the end of the long fabric of neurons are the output neurons.  The difference between output neurons and other neurons is that output neurons do not send signals to other neurons, but to devices that interact with the world outside of the network.  For biological networks, this might be a muscle, tear duct or gland, while in an artificial neural network, the output device might be a monitor, another computer, or a speaker.\r\n<BR><BR>\r\nThe way that these networks learn is extremely simple, yet extremely complex.  Input neurons respond to an input and signal positively or negatively various hidden neurons which signal other hiddens, which signal other hiddens, and so on until the output neurons are signaled, and some action is taken.  If the system likes the action, the nerves are "fed", if not the nerves are not "fed".  Over time, the system eliminates neural pathways that don''t produce a desired response to a given stimuli and keep neural pathways that do lead to the output desired.\r\n<BR><BR>\r\nOne of the key characteristics of these networks is that no neuron need know what effect it is having on any of the neurons it effects, nor does it need to know what causes the neurons up stream to fire.  In fact it doesn''t need to know anything.  It fires when signaled to fire. The collection of all of these neurons makes up what is considered "knowing" by producing appropriate outputs to given inputs.', 'Paul Osborne', 'neuralnetwork, neural net', 1, '', '', 'yes');
INSERT INTO `thepadc_ht100_compend` VALUES (50, 'parallel distributed processor', '(PDP) A system in which various parts of the system process different inputs simultaneously.  This is as opposed to a serial processor which has the entire system deal with one input at a time.  The advantage of the PDP is that it is much faster than the serial processor because it does a variety of operations on various inputs at the same time.', 'Paul Osborne', 'parallel processor, parallel processors, parallel processing, pdp, parallel distributed processors, parallel distributed processing, distributed processor, distributed processors, distributed processing', 1, '', '', 'yes');
INSERT INTO `thepadc_ht100_compend` VALUES (51, 'Skinner, B F', 'an American psychologist largely considered the leader of the behaviorist movement which dominated psychology in the first half of the 20th century.  Behaviorism argued that any behavior from a dog''s salivation, to a pianist''s playing could be attributed to behaviors learned through reward and punishment training.  The behaviorists are credited with the belief that what went on within the human mind, the "black box" was inconsequential as all behavior could be modified through reward and punishment.', 'Paul Osborne', 'Skinner, ''B F Skinner'', ''BF Skinner'', ''B.F. Skinner''', 1, '', '', 'yes');
INSERT INTO `thepadc_ht100_compend` VALUES (52, 'behaviorism', 'a psychological movement which dominated psychology in the first half of the 20th century.  Behaviorism argued that any behavior from a dog''s salivation, to a pianist''s playing, to love was learned through reward and punishment training or experiences.  The behaviorists are credited with the belief that what went on within the human mind, the "black box", was inconsequential as all behavior could be modified through reward and punishment.', 'Paul Osborne', 'behaviorist, behaviorists', 1, '', '', 'yes');
INSERT INTO `thepadc_ht100_compend` VALUES (53, 'intrinsic', 'having to do with or being a basic or central attribute of something.  \r\n<BR><BR>\r\n<strong>Intrinsic Understanding:</strong> innate, implicit awareness or knowledge that is not gained directly, and often results merely through experience or existence.\r\n', 'Paul Osborne', '"intrinsic understanding"', 1, '', '', 'yes');
INSERT INTO `thepadc_ht100_compend` VALUES (54, 'longitudinal study', 'research that follows an individual or group over a period of time  ', 'Paul Osborne', 'longitudinal, "longitudinal research"', 1, 'www.icpsr.umich.edu/NACJD/HELP/glossary.html', 'www.icpsr.umich.edu/NACJD/HELP/glossary.html', 'yes');
INSERT INTO `thepadc_ht100_compend` VALUES (55, 'development', 'maturation or growth.\r\n<BR><BR><strong>\r\nsee also <a href="http://www.mbecompendium.com/defbrowse.php#cognitivedevelopment">cognitive development</a></strong>', 'Paul Osborne', 'develop', 1, '', '', 'yes');
INSERT INTO `thepadc_ht100_compend` VALUES (56, 'cognitive development', 'the processes that the mind/brain goes through naturally as a person ages. While cognitive development does require some external stimulation, it is distinct from learning in that it is the mental growth that is spawned by spontaneous internal changes, while learning is the product of the internalization and processing of external data. Another distinction is that cognitive development usually, though not always, refers to what someone is mentally capable of knowing, while learning refers to what they know.\r\n', 'Paul Osborne', '', 1, '', '', 'yes');
INSERT INTO `thepadc_ht100_compend` VALUES (57, 'ethology', 'normally, the study of animal behavior, especially their social behaviors.  \r\n<BR><BR>\r\nThe less common meaning is that which applies to mind/brain; the study of the development and formation of human characteristics, often, the process is one by which the formation of human characters is theorized based on the assumption that the processes of animals'' are precursors or indicators of humans'' \r\n', 'Paul Osborne', '', 1, '', '', NULL);
INSERT INTO `thepadc_ht100_compend` VALUES (61, 'Universal Grammar', 'The definition tends to migrate between, "the system of principles, conditions, and rules that are elements or properties of all human languages," and, "genetically-determined state of the language faculty [language faculty: ability to use language]". According to Chomsky, this is because the rules are genetically-determined. Others might use only the first definition and/or doubt the genetic predetermination of Universal Grammar. ', 'Paul Osborne and Noam Chomsky', 'UG, "Universal Language"', 1, 'http://www.zmag.org/ZMag/grammar.htm', 'Universal Grammar & Linguistics by Michael Albert', NULL);
INSERT INTO `thepadc_ht100_compend` VALUES (59, 'neuroscience', 'the science of the anatomy, physiology, biochemistry, and/or the molecular biology of nerves and nervous system (especially the brain), with a concentration on their relation to behavior and learning', 'Paul Osborne', '', 1, '', '', NULL);
INSERT INTO `thepadc_ht100_compend` VALUES (60, 'paradigm', 'a view or model of how things work in the world or set of guidelines by which things act.', 'Paul Osborne', '', 1, '', '', NULL);

-- --------------------------------------------------------

-- 
-- Table structure for table `thepadc_ht100_undefined`
-- 

CREATE TABLE `thepadc_ht100_undefined` (
  `id` smallint(6) NOT NULL auto_increment,
  `word` varchar(50) NOT NULL default '',
  `wanter` varchar(250) NOT NULL default '',
  `counter` tinyint(4) default NULL,
  PRIMARY KEY  (`id`)
) TYPE=MyISAM COMMENT='These are the words that people want defined' AUTO_INCREMENT=86 ;

-- 
-- Dumping data for table `thepadc_ht100_undefined`
-- 

INSERT INTO `thepadc_ht100_undefined` VALUES (19, 'scheme', '', 1);
INSERT INTO `thepadc_ht100_undefined` VALUES (64, 'module', '', 1);
INSERT INTO `thepadc_ht100_undefined` VALUES (17, 'agency', '', 1);
INSERT INTO `thepadc_ht100_undefined` VALUES (5, 'modeling', '', 6);
INSERT INTO `thepadc_ht100_undefined` VALUES (62, 'model', 'test@mail.com', 8);
INSERT INTO `thepadc_ht100_undefined` VALUES (8, 'skill theory', '', 2);
INSERT INTO `thepadc_ht100_undefined` VALUES (10, 'web', 'unsubscribe@paul13.com', 2);
INSERT INTO `thepadc_ht100_undefined` VALUES (83, 'curiosity', '', 1);
INSERT INTO `thepadc_ht100_undefined` VALUES (84, 'motivation', '', 1);
INSERT INTO `thepadc_ht100_undefined` VALUES (14, 'modularity', 'universal grammar', 2);
INSERT INTO `thepadc_ht100_undefined` VALUES (80, 'compemdium', '', 1);
INSERT INTO `thepadc_ht100_undefined` VALUES (20, 'schemata', '', 1);
INSERT INTO `thepadc_ht100_undefined` VALUES (81, 'parietal', '', 1);
INSERT INTO `thepadc_ht100_undefined` VALUES (22, 'core knowledge', '', 1);
INSERT INTO `thepadc_ht100_undefined` VALUES (63, 'plomin', '', 1);
INSERT INTO `thepadc_ht100_undefined` VALUES (82, 'video', '', 1);
INSERT INTO `thepadc_ht100_undefined` VALUES (25, 'intelligence', '', 2);
INSERT INTO `thepadc_ht100_undefined` VALUES (26, 'inteligence', '', 1);
INSERT INTO `thepadc_ht100_undefined` VALUES (39, 'imperical', '', 1);
INSERT INTO `thepadc_ht100_undefined` VALUES (32, 'parasympathetic nervous system', '', 1);
INSERT INTO `thepadc_ht100_undefined` VALUES (33, 'sympathetic nervous system', '', 1);
INSERT INTO `thepadc_ht100_undefined` VALUES (34, 'emotion', '', 1);
INSERT INTO `thepadc_ht100_undefined` VALUES (67, 'transfer', '', 1);
INSERT INTO `thepadc_ht100_undefined` VALUES (36, 'epigenesis', '', 1);
INSERT INTO `thepadc_ht100_undefined` VALUES (78, 'chomsky', '', 1);
INSERT INTO `thepadc_ht100_undefined` VALUES (40, 'skill', '', 1);
INSERT INTO `thepadc_ht100_undefined` VALUES (57, 'Thought', 'Paul_Chua@post.harvard.edu', 1);
INSERT INTO `thepadc_ht100_undefined` VALUES (42, 'dyslexia', '', 1);
INSERT INTO `thepadc_ht100_undefined` VALUES (66, 'constraint', '', 1);
